// Track defines


// 62 segments of track in level1
// ROAD is 3 wide by 1 depth, rectangle (x,z)
// CORNERS are 3 x 3, square (x,z)

// how big the box around the trees etc is square
#define COL_DISTANCE_OBJ 700

#define TRACK_EDGE_LIMIT 2000

// the end letter is the entry direction
// North, South, East, West etc
// 1,2,3,4 are clockwise rotations starting at NW quarter

#define CORNER1N 1
#define CORNER2E 2
#define CORNER3S 3
#define CORNER4W 4
#define CORNER1W 5
#define CORNER2N 6
#define CORNER3E 7
#define CORNER4S 8

#define ROADN 10
#define ROADE 11
#define ROADS 12
#define ROADW 13
#define START 14

// Track objects layer
#define NONE 0
#define CONEN 1
#define CONES 2
#define CONEE 3
#define CONEW 4

#define TREE1N 5
#define TREE1S 6
#define TREE1E 7
#define TREE1W 8

#define SIGNR1 9
#define SIGNR2 10
#define SIGNR3 11
#define SIGNR4 12

#define SIGNL1 13
#define SIGNL2 14
#define SIGNL3 15
#define SIGNL4 16

#define CONENW 17
#define CONENE 18
#define CONESE 19
#define CONESW 20

#define ODDTREEN 21
#define ODDTREES 22
#define ODDTREEE 23
#define ODDTREEW 24

#define STADIUMN 25
#define STADIUMS 26
#define STADIUME 27
#define STADIUMW 28
#define TUNNELZ 29
#define TUNNELX 30

#define TREE2N 31
#define TREE2S 32
#define TREE2E 33
#define TREE2W 34

#define TREE3N 35
#define TREE3S 36
#define TREE3E 37
#define TREE3W 38

#define TREE4N 39
#define TREE4S 40
#define TREE4E 41
#define TREE4W 42

#define PSTARTZ 43
#define PSTARTX 44
#define LMTUNNELZ 45
#define LMTUNNELX 46
