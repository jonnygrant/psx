/* Player.h libraries
	Copyright (c) now3d 2000.  All rights reserved
*/
#ifndef player_h
#define player_h

#include "3d.h"


typedef struct
{
 TMDModel Man;
 TMDModel Board;
 SVECTOR Rotation;
 long Velocity;
 long LeanPlayer; // for leaning into the corner
}Player;


// Set the position of the Player  X
#define SetPlayerX(play, nx) (play)->Man.Coord.coord.t[0] += (nx), \
									  (play)->Man.Coord.flg = 0, \
									  (play)->Board.Coord.coord.t[0] += (nx), \
									  (play)->Board.Coord.flg = 0

// Set the position of the Player  Y
#define SetPlayerY(play, ny) (play)->Man.Coord.coord.t[1] += (ny), \
									  (play)->Man.Coord.flg = 0, \
									  (play)->Board.Coord.coord.t[1] += (ny), \
									  (play)->Board.Coord.flg = 0

// Set the position of the Player  Z
#define SetPlayerZ(play, nz) (play)->Man.Coord.coord.t[2] += (nz), \
									  (play)->Man.Coord.flg = 0, \
									  (play)->Board.Coord.coord.t[2] += (nz), \
									  (play)->Board.Coord.flg = 0

#endif
