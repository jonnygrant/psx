/* Load textures from main RAM into VRAM
	N3xus gave optimisation tip
   Copyright (c) now3d 2000.  All rights reserved
*/

#include <sys/types.h>
#include <libgte.h>
#include <libgpu.h>
#include <libgs.h>

/* Prototypes */
void LoadTim(long address);

/* Methods */
void LoadTim(long address)
{
 GsIMAGE timimage;

 // Get TIM attributes
 GsGetTimInfo((u_long *)(address+4),&timimage);

 // DMA transfer to VRAM, use cast to pass RECT
 LoadImage((RECT*)&timimage.px, timimage.pixel);

/* Is CLUT to be loaded as well? (only 4/8 bit)
  pmode Pixel mode
  0: 4-bit CLUT
  1: 8-bit CLUT
  2: 16-bit DIRECT
  3: 24-bit DIRECT
  4th bit signifies if
  CLUT present
*/
if(timimage.clut)
 {
  // Load the Colour Look Up Table
  LoadImage((RECT*)&timimage.cx, timimage.clut);
 }

 // Wait till the GPU has finished
 DrawSync(0);
}


