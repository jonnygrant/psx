/*
	sound.c Copyright (c) now3d 2000.  All rights reserved
	sound.c Play VAG files
	thx to kvaks for help
*/

#include <sys/types.h>
#include <libetc.h>
#include <libgte.h>
#include <libgpu.h>
#include <libgs.h>
#include <libmath.h>
#include <libsnd.h>
#include <libspu.h>
#include <stdio.h>


/*
pitch = (you_frequency<<12/44100)
when pitch = 0x0400 => 11025Hz
when pitch = 0x0800 => 22050Hz
when pitch = 0x1000 => 44100Hz

*/

#define MALLOC_MAX 6
char spu_malloc_rec [SPU_MALLOC_RECSIZ * (MALLOC_MAX + 1)];

void SoundLib_Init(void);
u_long SoundLib_LoadVag(char *sndaddrs, u_long size, u_long sndspeed);
void SoundLib_SoundOn(int ch, u_long sndspeed);
void SoundLib_WaitEndSound(int ch);
void SoundLib_FreeVag(u_long addr);

void SoundLib_Init(void)
{
  SpuCommonAttr c_attr;

  // Initialize SPU
  SpuInit ();
  SpuInitMalloc (MALLOC_MAX, spu_malloc_rec);
  // set common attributes (Master volume)
  c_attr.mask = (SPU_COMMON_MVOLL | SPU_COMMON_MVOLR);
  c_attr.mvol.left  = 0x3fff;                        // Master volume (left)
  c_attr.mvol.right = 0x3fff;                        // Master volume (right)

  SpuSetCommonAttr (&c_attr);
  SpuSetTransferMode (SpuTransByDMA);                // transfer by DMA
}

u_long SoundLib_LoadVag(char *sndaddrs, u_long size, u_long sndspeed)
{
  SpuVoiceAttr  s_attr;
  u_long        a_addr;

  sndaddrs += 0x30; // skip VAG Header
  //addr = (u_long*)malloc(size);

  // Transfer to Spu Memory

  a_addr = SpuMalloc (size);

  SpuSetTransferStartAddr(a_addr);
  SpuWrite((u_char*)sndaddrs,size);

  //while (! SpuIsTransferCompleted (SPU_TRANSFER_GLANCE)) ;


  //free((u_long*)addr);

  // setting of each voice attributes.

  // items of voice attribute
  s_attr.mask = (SPU_VOICE_VOLL       |
                 SPU_VOICE_VOLR       |
                 SPU_VOICE_PITCH      |
                 SPU_VOICE_WDSA       |
                 SPU_VOICE_ADSR_AMODE |
                 SPU_VOICE_ADSR_SMODE |
                 SPU_VOICE_ADSR_RMODE |
                 SPU_VOICE_ADSR_AR    |
                 SPU_VOICE_ADSR_DR    |
                 SPU_VOICE_ADSR_SR    |
                 SPU_VOICE_ADSR_RR    |
                 SPU_VOICE_ADSR_SL
                 );

  // set the attributes with all voice
  s_attr.voice = SPU_ALLCH;

  // value of each voice attribute
  s_attr.volume.left  = 0x3fff;               // Left volume 
  s_attr.volume.right = 0x3fff;               // Right volume 
  s_attr.pitch        = sndspeed;              // Pitch 
  s_attr.addr         = a_addr;               // Waveform data start address
  s_attr.a_mode       = SPU_VOICE_LINEARIncN; // Attack curve 
  s_attr.s_mode       = SPU_VOICE_LINEARIncN; // Sustain curve 
  s_attr.r_mode       = SPU_VOICE_LINEARDecN; // Release curve 
  s_attr.ar           = 0x0;                  // Attack rate value 
  s_attr.dr           = 0x0;                  // Decay rate value 
  s_attr.sr           = 0x0;                  // Sustain rate value 
  s_attr.rr           = 0x0;                  // Release rate value 
  s_attr.sl           = 0xf;                  // Sustain level value 

  SpuSetVoiceAttr (&s_attr);
 return a_addr;
}


void SoundLib_SoundOn(int ch, u_long sndspeed)
{
  SpuVoiceAttr s_attr;
  s_attr.mask = SPU_VOICE_PITCH;

  s_attr.voice = SPU_VOICECH(ch);
  s_attr.pitch = sndspeed + (sndspeed * ch / 12);
  SpuSetKeyOnWithAttr (&s_attr);

}


void SoundLib_WaitEndSound(int ch)
{
  while (SpuGetKeyStatus(ch)!=SPU_ON);
  while (SpuGetKeyStatus(ch)==SPU_ON);
}

// **************************************************************************
// SoundLib_FreeVag
// **************************************************************************
void SoundLib_FreeVag(u_long addr)
{
  SpuFree(addr);        
}




/*
 SpuInit();
 SsInit ();
 //SsStart();
 //SsSetMVol(127, 127);

 //temp= SND_VH;
 //printf("VH = %c%c%c%c\n", temp[0], temp[1], temp[2], temp[3]);

 SndBank = SsVabTransfer((u_char*)SND_VH, (u_char*)SND_VB, -1, SS_WAIT_COMPLETED);

 if (SndBank<0)  printf( "ERROR: VAB was not set up, code %d\n\n", SndBank);
 else printf("\n SndBank = %d\n", SndBank);  
 
 //SsVabTransCompleted (SS_WAIT_COMPLETED);

 printf("Sound play...\n");  // Vab#, Prog#, Tone#, Note, Fine, LeftVol, RightVol
 sndtemp = SsUtKeyOn(SndBank, 2, 0, 96, 20, 127, 127);
 

 //sndtemp = SsVoKeyOn(0x0002,0x5A00,127,127);
 printf("sndtemp = %d\n",sndtemp);

 //SsVoKeyOn(2, 96, 128, 128);
*/

/*

if (NPM_SetSong(APOCALY2_NPS, APOCALY2_NPI) == 0) printf("APOCALY2 was NOT set up\n");
else 
 { 
  printf("APOCALY2 was set up OK\n");
  NPM_Control(npPLAY);
 }

NPM_Control(npPAUSE);
printf("Loading VAG\n");

if (NPM_SfxLoad(0, NUM1_VAG)== 0) printf("NUM3 was NOT set up\n");
//else NPM_SfxPlay(10, 1);
 
NPM_SfxPlay( 0, 0 );
NPM_SfxPitch( 0, 0x400 );
NPM_SfxVol( 0, 0xff, 0xff );

*/
