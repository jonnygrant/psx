/* pad.h
   Copyright (c) now3d 2000.  All rights reserved
*/
#ifndef pad_h
#define pad_h

#define Pad0 0
#define Pad1 1
/*
  * All defined pad buttons are numbers as
  to save Processing time with (1<<12) etc

  ** it is only <<16 that differentiates the
  2 pads, so you can check different stuff
*/

/* Controller Pad 1 Defines */
#define Pad1L2          0x1    //1
#define Pad1R2          0x2    //10
#define Pad1L1          0x4    //100
#define Pad1R1          0x8    //1000
#define Pad1Triangle    0x10
#define Pad1Circle      0x20
#define Pad1Cross       0x40
#define Pad1Square      0x80

#define Pad1Select      0x100
#define Pad1Analog1     0x200
#define Pad1Analog2     0x400
#define Pad1Start       0x800

#define Pad1Up          0x1000
#define Pad1Right       0x2000
#define Pad1Down        0x4000
#define Pad1Left        0x8000

/* Controller Pad 2 Defines */
#define Pad2L2          0x10000
#define Pad2R2          0x20000
#define Pad2L1          0x40000
#define Pad2R1          0x80000
#define Pad2Triangle    0x10000
#define Pad2Circle      0x20000
#define Pad2Cross       0x40000
#define Pad2Square      0x80000

#define Pad2Select      0x100000
#define Pad2Analog1     0x200000
#define Pad2Analog2     0x400000
#define Pad2Start       0x800000

#define Pad2Up          0x1000000
#define Pad2Right       0x2000000
#define Pad2Down        0x4000000
#define Pad2Left        0x8000000

// Analog positions
// Highest and lowest boundarys for valid data
#define AnX1L           85
#define AnX1H           145
#define AnY1L           105
#define AnY1H           165

#define AnX2L           95
#define AnX2H           150
#define AnY2L           80
#define AnY2H           150


typedef struct
{
 char x1 ,y1, x2, y2;
} Analog;

#endif