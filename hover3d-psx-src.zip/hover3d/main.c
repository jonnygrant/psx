/*
	Hover Boarder 3D Copyright (c) now3d 2000.  All rights reserved
*/
#include <sys/types.h>
#include <libetc.h>
#include <libgte.h>
#include <libgpu.h>
#include <libgs.h>
#include <libmath.h>
#include <libsnd.h>
#include <libspu.h>
#include <stdio.h>

// My lib includes
#include "pad.h"
#include "addrs.h"
#include "3d.h"
#include "player.h"
#include "hitmod.h"

#define KIT_DIST 10
#define KITR 200
#define KITG 10
#define KITB 10

/* Structures */

extern GsSPRITE speedo, needle, grey, go, numbers[3], whirl2;

extern int currentviewpoint;
extern u_long ViewIntro;
extern u_long Pad, ScreenMode, ModeChanging;

GsSPRITE hover3d;
char *ProgName="Hover Boarding 3D", *ProgVer="1.0";

FontTexture Future;
FontTexture SmallFuture;
FontTexture Black;

GsBOXF Kit[8];
GsSPRITE edge, entry;

Player man;
WorldLevel WorldData;
GsFOGPARAM  Fog;

GsF_LIGHT Lights[2];
GsRVIEW2 ViewPoint;

u_long sndaddr;

long StartAnim[25]=
{
 178, 166, 154, 143, 131,
 120, 109, 98, 88, 78,
 69, 60 , 51 , 44, 36,
 30, 24, 18, 13, 9,
 6, 3, 1, 0, 0 };

u_char KitColour[24]=
{ 25 , 36 , 55 , 79 , 108 , 138 , 168 , 197 ,
 221 , 240 , 251 , 255 , 251 , 240 , 221 , 197 ,
 168 , 138 , 108 , 79 , 55 , 36 , 25 , 21 };

long KitPos=0, KitLoop;
char *temp;

/* Prototypes */
int main(void);
void InitSystem(void);
void StartIntro(void);
void InitKit(void);


/* Methods */
int main(void)
{
 InitSystem();

 StartIntro();

  while(1)
	{
	 ProcessPhysics(&man);
	 PrepareScreen();

	 // Update tracker viewpoint
	 GsSetRefView2(&ViewPoint);

	 DrawWorld(&WorldData);
	 DrawPlayer(&man);

	 FinishScreen();
	}

// Exit program
VSyncCallback(0);
StopCallback();
ResetGraph(3);
}


void InitSystem(void)
{
 printf("\n NOW3D Presents %s %s\n\n",ProgName, ProgVer);

 // Set up Graphics and World level
 Init3DGfx();
 Init3DWorld(&WorldData, &man);

 InitFont(&Future, (u_long)FUTURE_TIM, "ABCDEFGHIJKLMNOPQRSTUVWXYZ!-?. 3", 16, 16, 8, 4096, 4096);
 SetFontRGB(&Future, 128, 128, 200);

 InitFont(&SmallFuture, (u_long)FUTURE_TIM, "ABCDEFGHIJKLMNOPQRSTUVWXYZ!-?. 3", 16, 16, 8, 3584, 4096);
 SetFontRGB(&SmallFuture, 128, 128, 200);

 InitFont(&Black, (u_long)BLKMAIL_TIM, "abcdefghijklmnopqrstuvwxyz0123456789!?,.", 8, 8, 8, 4096, 4096);
 SetFontRGB(&Black, 150, 150, 250);

 printf("Loaded Extra Fonts\n");

 //load textures
 LoadTims();
 printf("Loaded textures into VRAM\n");

 InitTim(&numbers[0], (u_long)NUM1_TIM);
 InitTim(&numbers[1], (u_long)NUM2_TIM);
 InitTim(&numbers[2], (u_long)NUM3_TIM);
 InitTim(&go, (u_long)GO_TIM);
 InitTim(&grey, (u_long)GREY_TIM);
 InitTim(&hover3d, (u_long)HOVER3D_TIM);
 InitTim(&speedo, (u_long)SPEEDO_TIM);
 InitTim(&needle, (u_long)NEEDLE_TIM);
 InitTim(&whirl2, (u_long)WHIRL2_TIM);
 InitTim(&edge, (u_long)EDGE_TIM);
 InitTim(&entry, (u_long)ENTRY_TIM);
 SetTimPos(&entry, 0, -40);

 SetTimPos(&numbers[0], 90, -40);
 SetTimPos(&numbers[1], 90, -40);
 SetTimPos(&numbers[2], 90, -40);
 SetTimPos(&go, 90, -40);
 SetTimPos(&grey, 0, -10);
 SetTimPos(&speedo, -110, 75);
 BitSet(&speedo.attribute, 1<<30);
 SetTimPos(&needle, -110, 85);
 needle.rotate = 3100<<12;
 needle.my = needle.h;
 SetTimPos(&whirl2, 130, 75);
 SetTimScale(&whirl2, 2560, 2560);
 
 // make it transparent and fit the screen
 BitSet(&grey.attribute, 1<<30);
 SetTimScale(&grey, 20480, 20480);
 //SetTimRGB(&grey, 128, 128, 128);

 //printf("\n attribute=%d",(grey.attribute>>30) &1);

 // Set up DualShock pads
 InitDSPads();


 // setup player models and start pos etc
 InitPlayer(&man);

 // Both light sources  lnum ,x,y,z, r,g,b
 InitLight(&Lights[0], 0, 1, 1, 1, 150, 150, 150);
 InitLight(&Lights[1], 1, -1, 1, -1, 150, 150, 150);
 GsSetAmbient(0, 0, 0);
 printf("Setup Player and 2 Lights\n");

 MOD_Init();
 MOD_Load((u_char*)APOCALY2_HIT);



 //SoundLib_Init();

 //SoundLib_WaitEndSound(0);
 //SoundLib_FreeVag(sndaddr);


/*
 Fog.dqa = -15000; // The move negative the further away
 Fog.dqb = 40000000; //  50,000,000 sharp fade   18,000,000 gradual fade
 Fog.rfc = 0;
 Fog.gfc = 0;
 Fog.bfc = 0;
 GsSetLightMode(2);
 GsSetFogParam(&Fog);
 printf("Set up Fogging\n");
*/

InitKit();

 Pad = DSPadRead();

 if ((Pad&Pad1R2) && (Pad&Pad1L2) && (ModeChanging == FALSE))
  {
	ScreenMode = !ScreenMode;
	SetVideoMode(ScreenMode);

	ModeChanging = TRUE;
	if (ScreenMode==0) printf("Screen Mode changeing to NTSC\n");
	else printf("Screen Mode changeing to PAL\n");
   }	

}


void StartIntro(void)
{
 long x=0, y=0, temp, strobe=25; // for the loop and for flashing start text

 SetTimRGB(&entry, 0, 0, 0);
 for (x=20; x<500; x+=4)
  {
	PrepareScreen();
	if (x>0 && x<200) y = x;
	if (x>=200 && y>0) y -= 4;
	SetTimRGB(&entry, y, y, y);
	GsSortSprite(&entry, &OTable[ActiveBuffer], 0);
	FinishScreen();
  }

 SetTimPos(&edge, 0, -30);

 while (strobe > 0)
 {
  SetTimRGB(&edge, (25-strobe)*5, (25-strobe)*5, (25-strobe)*5+40);
 // printf("while x=%d strobe=%d\n",x, strobe);
  for (x=0; x < strobe >> 3; x++)
   {
    PrepareScreen();
//  printf("for x=%d strobe=%d\n",x, strobe);
      GsSortSprite(&edge, &OTable[ActiveBuffer], 0);
    FinishScreen();
   }
  for (x=0; x < strobe >> 3; x++)
   {
    PrepareScreen();
    FinishScreen();
   }

  strobe--;
 }//endwhile

for (x=0; x<40; x++)
 {
  PrepareScreen();
   GsSortSprite(&edge, &OTable[ActiveBuffer], 0);
  FinishScreen();
 }

 MOD_Start();
 Pad = DSPadRead();
 //printf("Running mod and starting anim\n");

 for (x=0; x<25; x++)
  {
   //FntPrint("X=%d Anim=%d\n", x, StartAnim[x]);
   //printf("SetTimPos \tx = %d\ty = %d\n", StartAnim[x], -20 -(x<<2));

   PrepareScreen();
	SetTimPos(&hover3d, StartAnim[x], 20 -(x<<2));
	GsSortSprite(&hover3d, &OTable[ActiveBuffer], 0);
   FinishScreen();
  }

 //printf("Finished start intro\n");

 x=10; // set the press start logo to wait 

  for (KitLoop=0; KitLoop<8; KitLoop++)
   {
	Kit[KitLoop].r = KitColour[(KitPos+KitLoop)%24];
   }
  

 while(!(Pad&Pad1Start))
 {
  PrepareScreen();
  Pad = DSPadRead();
  GsSortSprite(&hover3d, &OTable[ActiveBuffer], 0);
	if (x%16<10) DispText(&SmallFuture, "PRESS START", -35, 55);
	x++;

  for (KitLoop=0; KitLoop<8; KitLoop++) Kit[KitLoop].r = KitColour[(KitPos+KitLoop)%24];
   
  for (temp=0; temp<8; temp++) GsSortBoxFill(&Kit[temp], &OTable[ActiveBuffer], 0);
  KitPos++;
  KitPos = KitPos%24;
  //FntPrint("KitPos = %d\n", KitPos);

  FinishScreen();
 }

 MOD_Stop();
 MOD_Free();
}



void InitKit(void)
{
 long loop, loop2=0;

 for (loop=-70; loop<70; loop += KIT_DIST*2)
  {
   //printf("loop = %d loop2 = %d\n", loop, loop2);
   Kit[loop2].attribute = 0x00000000;
   Kit[loop2].x = loop;
   Kit[loop2].y = 70;
   Kit[loop2].w = Kit[loop2].h = 10;
   Kit[loop2].r = 20;
   Kit[loop2].g = Kit[loop2].b = 10;
   loop2++;
  }

} // end function

