/* loadtims.c created by PSXMEM V3.0 */

/* Loads TIM files from main RAM into there VRAM co-ords */

#include "addrs.h"

/* Prototypes */
void LoadTims(void);

/* Methods */
void LoadTims(void)
{
 LoadTim(NOW3D_TIM);
 LoadTim(GROUND_TIM);
 LoadTim(GRASS_TIM);
 LoadTim(REDWHITE_TIM);
 LoadTim(NEWFONT_TIM);
 LoadTim(FUTURE_TIM);
 LoadTim(START_TIM);
 LoadTim(CHEVRONS_TIM);
 LoadTim(PEOPLE_TIM);
 LoadTim(NUM1_TIM);
 LoadTim(NUM2_TIM);
 LoadTim(NUM3_TIM);
 LoadTim(GO_TIM);
 LoadTim(GREY_TIM);
 LoadTim(WHIRL1_TIM);
 LoadTim(WHIRL2_TIM);
 LoadTim(PSTART_TIM);
 LoadTim(BLKMAIL_TIM);
 LoadTim(HOVER3D_TIM);
 LoadTim(SPEEDO_TIM);
 LoadTim(NEEDLE_TIM);
 LoadTim(EDGE_TIM);
 LoadTim(ENTRY_TIM);
}
