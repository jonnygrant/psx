/* Hover 3D
	Copyright (c) now3d 2000.  All rights reserved
*/
#include <stdio.h>
#include <sys/types.h>
#include <libgte.h>
#include <libgpu.h>
#include <libgs.h>

#include "pad.h"
#include "addrs.h"
#include "3d.h"
#include "player.h"


// The amount the player is above the surface of the road & on the z axis
#define YOFFSET -600
#define ZOFFSET -1600

extern GsRVIEW2 ViewPoint;
extern Player man;
extern int currentviewpoint;

static u_long PlayerAnimPos=0;
Analog An;
u_long ViewIntro=TRUE;
u_long IntroPosition=0;

// Floating data for player (generated with sinlab)
int PlayerAnimData[100]=
{ 1 , 2 , 2 , 3 , 4 , 4 , 5 , 6 ,
 6 , 7 , 8 , 8 , 9 , 9 , 10 , 10 ,
 11 , 11 , 11 , 11 , 12 , 12 , 12 , 12 ,
 12 , 12 , 12 , 12 , 12 , 11 , 11 , 11 ,
 11 , 10 , 10 , 9 , 9 , 8 , 8 , 7 ,
 6 , 6 , 5 , 4 , 4 , 3 , 2 , 2 ,
 1 , 0 ,-1 ,-2 ,-2 ,-3 ,-4 ,-4 ,
-5 ,-6 ,-6 ,-7 ,-8 ,-8 ,-9 ,-9 ,
-10 ,-10 ,-11 ,-11 ,-11 ,-11 ,-12 ,-12 ,
-12 ,-12 ,-12 ,-12 ,-12 ,-12 ,-12 ,-11 ,
-11 ,-11 ,-11 ,-10 ,-10 ,-9 ,-9 ,-8 ,
-8 ,-7 ,-6 ,-6 ,-5 ,-4 ,-4 ,-3 ,
-2 ,-2 ,-1 , 0 };

int ViewpointAnim[80]=
{
 4800 , 4727 , 4653 , 4580 ,
 4507 , 4434 , 4361 , 4289 ,
 4216 , 4144 , 4072 , 4001 ,
 3930 , 3859 , 3788 , 3718 ,
 3649 , 3580 , 3512 , 3444 ,
 3376 , 3310 , 3244 , 3178 ,
 3114 , 3050 , 2987 , 2925 ,
 2863 , 2803 , 2743 , 2684 ,
 2626 , 2569 , 2513 , 2458 ,
 2404 , 2351 , 2299 , 2249 ,
 2199 , 2151 , 2103 , 2057 ,
 2012 , 1968 , 1926 , 1885 ,
 1845 , 1806 , 1769 , 1733 ,
 1698 , 1665 , 1633 , 1603 ,
 1573 , 1546 , 1520 , 1495 ,
 1471 , 1449 , 1429 , 1410 ,
 1392 , 1376 , 1362 , 1349 ,
 1338 , 1328 , 1319 , 1312 ,
 1307 , 1303 , 1301 , 1300 };


// Prototypes
void InitPlayer(Player *Models);
void DrawPlayer(Player *Models);
void UpdatePlayer(Player *Models, long nd);
void RotatePlayer(Player *play, long ny);
void AnimatePlayer(Player *play);

// Methods

// Set up models with correct VECTORs and MATRIXes
void InitPlayer(Player *Models)
{
 InitTmd(&Models->Man, (u_long *)MAN_TMD, 40);
 SetTmdPos(&Models->Man, 1, -20 +YOFFSET, 1+ZOFFSET);

 // Set up model
 InitTmd(&Models->Board, (u_long *)BOARD_TMD, 40);
 SetTmdPos(&Models->Board, 1, YOFFSET, 1+ZOFFSET);

 // clear the rotation.
 Models->Rotation.vy = Models->Rotation.vx = 0;
 Models->Rotation.vz = ONE;
 Models->Velocity = 0;
 Models->LeanPlayer = 0;
 printf("\nPlayer initalised\n");
}

// Draw the 2 player models
void DrawPlayer(Player *Models)
{
 // Draw all the models
 if (!(currentviewpoint==2))
  {
	DrawModel(&Models->Man);
	DrawModel(&Models->Board);
  }
}

// Calc new direction from VECTOR with new change
void UpdatePlayer(Player *Models, long nd)
{
 VECTOR temp, direction;
 if (nd!=0)   // check for divide by 0
  {
	temp.vx=temp.vy=0;
	temp.vz=4096;
	ApplyMatrixLV(&Models->Man.Coord.coord, &temp, &direction);

	// move MAN model in direction
	Models->Man.Coord.coord.t[0] += (direction.vx*nd)>>12;
	Models->Man.Coord.coord.t[1] += (direction.vy*nd)>>12;
	Models->Man.Coord.coord.t[2] += (direction.vz*nd)>>12;
	Models->Man.Coord.flg=0;

	ApplyMatrixLV(&Models->Board.Coord.coord, &temp, &direction);

	// move BOARD model in direction
	Models->Board.Coord.coord.t[0] += (direction.vx*nd)>>12;
	Models->Board.Coord.coord.t[1] += (direction.vy*nd)>>12;
	Models->Board.Coord.coord.t[2] += (direction.vz*nd)>>12;
	Models->Board.Coord.flg=0;
  }
}


// Rotate direction and model in the y-axis also lean into corners
void RotatePlayer(Player *play, long ny)
{
 long PlayTemp; // for play->LeanPlayer

 // reset matrix to identity
 ResetMatrix(play->Man.Coord.coord.m);

 play->Rotation.vy+=ny;

 // loop around as 360 degrees = 4096 psx degrees
 if (play->Rotation.vy > 4096) play->Rotation.vy-=4096;
 else if (play->Rotation.vy < 0) play->Rotation.vy +=4096;

 PlayTemp = play->LeanPlayer;
 // update the turning angle of the player
 if ((PlayTemp<70) && (PlayTemp>-70)) play->LeanPlayer += (ny>>3);
 //FntPrint("ny=%d (ny>>4)=%d\n",ny,(ny>>4));
 else if (((PlayTemp>70) && (PlayTemp<80)) || ((PlayTemp<-70) && (PlayTemp>-80)))  play->LeanPlayer += (ny>>4);



 play->Rotation.vz = ONE + 5 * play->LeanPlayer;
 if (play->Rotation.vz>4096) play->Rotation.vz -=4096;


 if (play->Rotation.vy!=0)
  {
	RotMatrix(&play->Rotation, &play->Man.Coord.coord);
	play->Man.Coord.flg=0;

	RotMatrix(&play->Rotation, &play->Board.Coord.coord);
	play->Board.Coord.flg=0;
  }

}

void AnimatePlayer(Player *play)
{
 //FntPrint("\nAnim=%d %d",PlayerAnimPos, PlayerAnimData[PlayerAnimPos]);
 if (ViewIntro==TRUE)
  {
	//printf("\n ViewIntro TRUE");
	InitTrackerView(&ViewPoint, &man.Man, 180, 0, -ViewpointAnim[IntroPosition], -4200 + (IntroPosition<<5), 0, -200, 1000, 1474560);
	// goes from -4000 -> -1800 the start pos
	// <<5 is *32 optimised

	IntroPosition++;
	if (IntroPosition>75)
	 {
	  ViewIntro=FALSE;
	  IntroPosition=0;
	 }
  }
 else
  {
	//printf("\n else %d",ViewIntro);
	SetPlayerY(play, PlayerAnimData[PlayerAnimPos]);
	PlayerAnimPos = (PlayerAnimPos+1)%100;
  }
}
