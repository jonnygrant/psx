/* Dual Shock Pad libs
	Copyright (c) now3d 2000.  All rights reserved
*/

#include <sys/types.h>
#include <libgte.h>
#include <libgpu.h>
#include <libgs.h>
#include <libpad.h>
#include "pad.h"


// Buffers for sending and receiving
u_char PadReceiveBuffer[2][34];
u_char PadSendBuffer[2][6];

// re-align the buffer
u_char align[6]={0,1,0xFF,0xFF,0xFF,0xFF};

/* prototypes */
void InitDSPads(void);
u_long DSPadRead(void);
void WaitStablePad(int);
void AlignPad(char);
void SendDSPad(char, char, char);
void ReInitPad(char pad);
void DispPadDataHex(char Pad);
void DispPadDataBin(char Pad);
void ReadAnalog(char Pad, Analog *An);
char ReadPadType(char Pad);
char CheckPad(char Pad);

/* methods */
void InitDSPads(void)
{
 int x,y;
  // Initalise receive buffers for both pads
  PadInitDirect(PadReceiveBuffer[Pad0], PadReceiveBuffer[Pad1]);

  // Enable both pads
  PadStartCom();
  PadEnableCom(3);

  // This clears all data in the buffer to stop any false info
  for (y=0; y<2; y++)    // both pads
	 for(x=0; x<6;x++) PadSendBuffer[y][x]=0x00;  // clear all

  WaitStablePad(Pad0);
  // Sets up the send buffer (call only once)
  PadSetAct(Pad0, PadSendBuffer[Pad0], 6);

  // Pad1 set up....
  //WaitStablePad(Pad1);
  //PadSetAct(Pad1, PadSendBuffer[Pad1], 8);

  // Align the pad actuators
  AlignPad(Pad0);

  WaitStablePad(Pad0);	
  printf("\nPad Mode= %d\n",PadInfoMode(Pad0, 1, 2));	
}

u_long DSPadRead(void)
{
 return(~(*(*PadReceiveBuffer+3) | *(*PadReceiveBuffer+2) << 8 | *(*PadReceiveBuffer+3) << 16 | *(*PadReceiveBuffer+2) << 24));
}

void DispPadDataHex(char Pad)
{  int x;

 for(x=0;x<8;x++) printf(" %X",PadReceiveBuffer[Pad][x]);
 printf("\n\n");
}

void DispPadDataBin(char Pad)
{  int x,y;

 for(x=2;x<4;x++)
  { printf("x=%d ",x);
	 for (y=7; y>-1; y--)
	  {
		printf("%d",~(PadReceiveBuffer[Pad][x]>>y) &1);
	  }
	printf(" ");
	//if (x==3) printf("\n");
  }

 printf("\n\n");
}


void ReadAnalog(char Pad, Analog *An)
{
 // update the Analog struct values
 An->x2 = PadReceiveBuffer[Pad][4];
 An->y2 = PadReceiveBuffer[Pad][5];
 An->x1 = PadReceiveBuffer[Pad][6];
 An->y1 = PadReceiveBuffer[Pad][7];
}


void WaitStablePad(int port)
{
 // Loop while the pad is not in state 6
 while (PadGetState(port)!=PadStateStable)
 {
  PrepareScreen();
  FntPrint("Plug in a pad\n");
  FinishScreen();
 }
}

void AlignPad(char Pad)
{
 WaitStablePad(Pad);
 // Align the pad actuator
 if (!PadSetActAlign(Pad, align)) {printf("Error with pad %d's actuators",Pad); exit(-1);}
}

void SendDSPad(char PadNo, char Pos, char Value)
{
// Send data into the pad buffer
 PadSendBuffer[PadNo][Pos] = Value;
}

void ReInitPad(char pad)
{
 WaitStablePad(pad);
 PadSetAct(pad, PadSendBuffer[pad], 8);

 // Re-align the pad
 AlignPad(pad);
}

char ReadPadType(char Pad)
{
 return PadReceiveBuffer[Pad][1];
}

char CheckPad(char Pad)
{
 return PadReceiveBuffer[Pad][0];
}
