/* Realistic physics of the hover board player
   Copyright (c) now3d 2000.  All rights reserved
*/
#include <stdio.h>
#include <sys/types.h>
#include <libgte.h>
#include <libgpu.h>
#include <libgs.h>
#include <rand.h>

#include "pad.h"
#include "3d.h"
#include "player.h"
#include "addrs.h"

#include "track.h"

extern Analog An;
extern FontTexture Future;
extern FontTexture SmallFuture;
extern FontTexture Black;
extern GsRVIEW2 ViewPoint;
extern u_long ViewIntro, IntroPosition, ScreenMode, SndBank;
extern WorldLevel WorldData;

u_long Pad=0;
u_long currentviewpoint=0;
u_long tripressed = FALSE;
u_long startpressed = TRUE, pausemenu = FALSE;
u_long padconnected = FALSE;
u_long EngineTime=0, BestTime=0;
u_long IntroTime=0, scaletemp;
u_long GameRunning=FALSE;
u_long GoRunning = TRUE;
u_long UpdatePhysics = FALSE;
u_long ModeChanging = FALSE, analogmode=FALSE;
u_long SpareLoop=0;
u_long vpx,vpy,vpz,rz;
u_long secs,mins,ofsecs;

long speedtemp=0, velocitytemp, temp;

GsSPRITE numbers[3], go, grey, speedo, needle, whirl2;


// Prototypes
void ProcessPhysics(Player *play);
void ProcessPad(Player *play);
void CheckViewPoint(Player *play);
void DebugPauseMenu(Player *play);
void ControlPlayer(Player *play);
void DisplayScreen(Player *play);
void CollisionDetection(Player *play);
void ControlTiming(void);
void Credits(void);
void RandomTMD(TMDModel *model);


// Methods

// Realistic physics model
void ProcessPhysics(Player *play)
{    
 if (ReadPadType(Pad0)==0x73)  // is the red LED on?
	 {
	  if (analogmode==FALSE)
		{
		 printf("Analog so reinitalise vibration\n");
		 ReInitPad(Pad0);
		 analogmode=TRUE;
		}
      }
 else analogmode=FALSE;

 if (ViewIntro==FALSE && GameRunning==TRUE)
  {
	//printf("time= %d\n",EngineTime);
	// if in pause menu or not analog mode, do not update physics
	if (pausemenu==FALSE && UpdatePhysics==TRUE)
	 {
	  // move along at the current speed
	  UpdatePlayer(play, play->Velocity*2);
	  ControlTiming(); // check segment completion and update EngineTime
	 }
	}
 else if (pausemenu==TRUE); // go no further

 // ViewIntro is the sin curve anim
 else if (IntroPosition>60)
	 {
	 /* if (IntroTime==10) 
       {
	    //printf("Playing NUM3\n");
		SoundLib_LoadVag(NUM3_VAG, NUM3_VAG_SIZE, 0x1000);
        SoundLib_SoundOn(14, 0x1000);
       }
	   */
	  scaletemp = 3072+200*IntroTime;
	  SetTimScale(&numbers[2], scaletemp, scaletemp);
	  GsSortSprite(&numbers[2], &OTable[ActiveBuffer], 0);
	  IntroTime++;
	 }

 else if (ViewIntro==FALSE && GameRunning==FALSE)
  {
	if (IntroTime<25)
	 {
	  
	  scaletemp = 3072 + 200 * IntroTime;
	  SetTimScale(&numbers[2], scaletemp, scaletemp);
	  GsSortSprite(&numbers[2], &OTable[ActiveBuffer], 0);
	 }
	else if (IntroTime<50)
	 {
	  /*if (IntroTime==40) 
       {
	    //printf("Playing NUM2\n");
		SoundLib_LoadVag(NUM2_VAG, NUM2_VAG_SIZE, 0x1000);
        SoundLib_SoundOn(14, 0x1000);
       }
	   */
	  scaletemp = 3072+200*(IntroTime-25);
	  SetTimScale(&numbers[1], scaletemp, scaletemp);
	  GsSortSprite(&numbers[1], &OTable[ActiveBuffer], 0);
	 }
	else if (IntroTime<75)
	 {
	  /*if (IntroTime==65) 
       {
	    //printf("Playing NUM1\n");
		SoundLib_LoadVag(NUM1_VAG, NUM1_VAG_SIZE, 0x1000);
        SoundLib_SoundOn(14, 0x1000);
       }*/
	  scaletemp = 3072+200*(IntroTime-50);
	  SetTimScale(&numbers[0], scaletemp, scaletemp);
	  GsSortSprite(&numbers[0], &OTable[ActiveBuffer], 0);
	 }
	else if (IntroTime==75) GameRunning=TRUE;
	IntroTime++;
  } // end of elseif

  if (GoRunning==TRUE && GameRunning==TRUE && pausemenu==FALSE)
	 {
     /* if (IntroTime==90) 
       {
	    //printf("Playing GO\n");
		SoundLib_LoadVag(GO_VAG, GO_VAG_SIZE, 0x1000);
        SoundLib_SoundOn(2, 0x1000);
       }*/
	  if (IntroTime ==100)  
	   {
	    MOD_Load((u_char*)DRAGOJIV_HIT);
        MOD_Start();
       }
	 
	  scaletemp = 3072+100*(IntroTime-75);
	  SetTimScale(&go, scaletemp, scaletemp);
	  GsSortSprite(&go, &OTable[ActiveBuffer], 0);

	  IntroTime++;
	  if (IntroTime>100) GoRunning=FALSE;
     //if (IntroTime==80)  MOD_Start();  // start music
	 }

  if (pausemenu==FALSE) AnimatePlayer(play);

  ProcessPad(play);
  CollisionDetection(play);
  DisplayScreen(play);
}


void ProcessPad(Player *play)
{
if (CheckPad(Pad0)!=FALSE) //if pad in port
 {
  if (SpareLoop%20<10)
	{
	 DispText(&Future, "PLEASE RECONNECT", -60, -20);
	 DispText(&Future, " THE PAD !", -20, 0);
	}
  UpdatePhysics=FALSE;
  SpareLoop++;
 }
 else // there is a pad
 {
 Pad = DSPadRead();

 if ((Pad&Pad1R2) && (Pad&Pad1L2) && (ModeChanging == FALSE))
  {
	ScreenMode = !ScreenMode;
	SetVideoMode(ScreenMode);

	ModeChanging = TRUE;
	if (ScreenMode==0) printf("Screen Mode changeing to NTSC\n");
	else printf("Screen Mode changeing to PAL\n");
	
  }
 else if  ((!(Pad&Pad1R2) && (Pad&Pad1L2)) && (ModeChanging == TRUE))
  {
	ModeChanging = FALSE;
  }

 CheckViewPoint(play);

 //printf("\n Pad Type %X",ReadPadType(Pad0));

 if (ReadPadType(Pad0)!=0x73)  // is the red LED off?
  {
	if (SpareLoop%20<10) DispText(&Future, "SWITCH ANALOG ON !", -70, -20);
	UpdatePhysics=FALSE;
	SpareLoop++;
  }
 else
 {
  UpdatePhysics=TRUE;
  ReadAnalog(Pad0, &An);

  // clever code to avoid repeated changes of start value
  if ((Pad&Pad1Start)&&(startpressed==FALSE))
	{
	 startpressed=TRUE;

	 if (pausemenu==TRUE) pausemenu=FALSE;
	 else pausemenu=TRUE;
	 //printf("\npausemenu=%d", pausemenu);
	}
  else if ((!(Pad&Pad1Start))&(startpressed==TRUE)) startpressed=FALSE;

  if (pausemenu==TRUE) DebugPauseMenu(play);
  else  ControlPlayer(play);

 }// end analog pad if
 }//end check pad in port if
}


void CheckViewPoint(Player *play)
{
 if ((Pad&Pad1Triangle)&&(tripressed==FALSE))
  {
	currentviewpoint = (currentviewpoint+1)%3;
	//printf("\ncurrentviewpoint=%d",currentviewpoint);
	 switch(currentviewpoint)
	 {
	  case 0:
		{
		 InitTrackerView(&ViewPoint, &play->Man, 180, 0, -1300, -1800, 0, -200, 1000, 1474560);
		 break;
		}
	  case 1:
		{
		 InitTrackerView(&ViewPoint, &play->Man, 180, 0, -2000, -2800, 0, -200, 1000, 1474560);
		 break;
		}
	  case 2:
		{
		 InitTrackerView(&ViewPoint, &play->Man, 180, 0, -900, -1500, 0, -200, 1000, 1474560);
		 break;
		}
	 } // end switch
	tripressed=TRUE;
	//printf("\n set tri 1");
  } // end if
 //printf("\n%d",!(Pad&Pad1Triangle));

 else if ((!(Pad&Pad1Triangle))&(tripressed==TRUE))
  {
	tripressed=FALSE;
  }
}// end fucntion



// If the user wants to change the viewpoint on the player
// or other cool debug/pause menu stuff
void DebugPauseMenu(Player *play)
{
 // Spare loop is used to flash the message on and off
 if (SpareLoop%16<6) DispText(&SmallFuture, "PAUSED", 115, 100);
 SpareLoop++;

 // Draw backgournd and menus
 GsSortSprite(&grey, &OTable[ActiveBuffer], 0);

 DispText(&Black, "menu", 0, -65);
 DispText(&Black, "use analog sticks", -50, -50);
 DispText(&Black, "to change the viewpoint", -50, -40);

 DispText(&Black, "press select to reset", -50, -20);
 
 DispText(&SmallFuture, "PRESS RI FOR GREETZ", -90, 50);
 
 if (Pad&Pad1R1) Credits();

 if (Pad&Pad1Select) // reset the Playstation
 {
  printf("\n SELECT pressed, so reset");
  asm("lui $2,0xbfc0");
  asm("j $2");
 }

 vpx = ViewPoint.vpx;
 vpy = ViewPoint.vpy;
 vpz = ViewPoint.vpz;
 rz = ViewPoint.rz;

 // Rap around the (4096*360) boundary of rotation
 if (rz>-12288) rz-= 1474560;
 if (Pad&Pad1Cross) printf("\nInitTrackerView %d,%d,%d,%d",vpx,vpy,vpz,rz);

 // Modify the Z axis viewpoint
 if (An.y1<AnY1L)	vpz	+= (AnY1L-An.y1);
 else if (An.y1>AnY1H) vpz -= (An.y1-AnY1H);

 // Modify the X axis viewpoint
 if (An.x1<AnX1L)	vpx -= (AnX1L-An.x1);
 else if (An.x1>AnX1H)
  {
	if (An.x1>230) vpx += 85; // limit the response range
	else vpx += (An.x1-AnX1L);
  }

 // Modify the Y axis viewpoint
 if (An.y2<AnY2L)	vpy -= (AnY2L-An.y2);
 else if (An.y2>AnY2H) vpy += (An.y2-AnY1H);

 // Modify the viewpoint twist RZ
 if (An.x2<AnX2L)	rz += (An.x2-AnX2L)<<7;
 else if (An.x2>AnX2H)
  {
	if (An.x2>245) rz += 12160; // limit the responce range
	else rz -= (AnY2H-An.x2)<<7;
  }

 InitTrackerView(&ViewPoint, &play->Man, 180, vpx, vpy, vpz, 0, -200, 1000, abs(rz));
} // end fucntion


void ControlPlayer(Player *play)
{
 //digital controls
 if (Pad&Pad1Left) RotatePlayer(play, -40);
 if (Pad&Pad1Right) RotatePlayer(play, 40);
 // turbo
 if (GameRunning == TRUE) //don't want the turbo going b4 the start
  {
   if (Pad&Pad1Cross)  UpdatePlayer(play, 60);
   if (Pad&Pad1Circle) UpdatePlayer(play, -40);
  }
  
 //if (Pad&Pad1Square) SendDSPad(Pad0, 0, 1);

 // local speed variable
 velocitytemp = play->Velocity;

 // stop the wandering player!
 if ((velocitytemp==1)||(velocitytemp==-1)) play->Velocity = velocitytemp = 0;

 // stop the wandering viewpoint!
 if ((play->LeanPlayer==1)||(play->LeanPlayer==-1)) play->LeanPlayer = 0;

 // Increase velocity proportionaly to the movement on the analog stick
 if ((An.y1<AnY1L)&&(velocitytemp<80)) play->Velocity += (AnY1L-An.y1)>>5;


 else if ((An.y1>AnY1H)&&(velocitytemp>-30))
  {
   // for on gras it will not start to move backwards..
	if (play->Velocity ==0) play->Velocity = -4;
	else play->Velocity -= (An.y1-AnY1H)>>5;
  }

 else if (velocitytemp>=2)  // if no throttle, velocity slows at -2 per frame
  {
	//printf("\nvtmp-2 =%d",velocitytemp);
	play->Velocity = velocitytemp-2;
  }
 else if (velocitytemp<= -2)  // if no reverse, velocity slows at +2 per frame
  {
	//printf("\nvtmp+2 =%d",velocitytemp);
	play->Velocity = velocitytemp+2;
  }

  // break after leaning into corners
  if (play->LeanPlayer<0) play->LeanPlayer+=2;
  else if (play->LeanPlayer>0) play->LeanPlayer-=2;

  // Turn the player
  if (An.x1<AnX1L) RotatePlayer(play, (An.x1-AnX1L)>>1);
  else if (An.x1>AnX1H)
	{
	 if (An.x1>230) RotatePlayer(play, 42); // limit the responce range
	 else RotatePlayer(play, (An.x1-AnX1H)>>1);
	}

 // send 0 just to recalc the matrix
 RotatePlayer(play, 0);
} // end of fucntion


void DisplayScreen(Player *play)
{
 velocitytemp = play->Velocity;    // local speed variable
 mins = EngineTime/1500;         // mins   25*60=1500
 secs = (EngineTime%1500)/25;    // secs= remainder after seconds removed div 25fps
 ofsecs = (EngineTime%25<<2)/10; // 1/10 of a second = remainder after secs removed

 if (secs<10) FntPrint("Speed: %2d kmh   Time: %2d:%d%d:%d\n", velocitytemp>>1, mins, 0, secs, ofsecs);
 else FntPrint("Speed: %2d kmh   Time: %2d:%2d:%d\n",velocitytemp/2, mins, secs, ofsecs);

// Best time
 mins = BestTime/1500;         // mins   25*60=1500
 secs = (BestTime%1500)/25;    // secs= remainder after seconds removed div 25fps
 ofsecs = (BestTime%25<<2)/10; // 1/10 of a second = remainder after secs removed

 if (secs<10) FntPrint("                Best: %2d:%d%d:%d\n", mins, 0,secs, ofsecs);
 else FntPrint("                Best: %2d:%2d:%d\n", mins, secs, ofsecs);

 //FntPrint("LeanPlayer = %d\n", play->LeanPlayer);
 //FntPrint("rotate = %d\n", needle.rotate>>12);

 needle.rotate = ((velocitytemp*2)-80) <<12;
 GsSortSprite(&needle, &OTable[ActiveBuffer], 0);
 GsSortSprite(&speedo, &OTable[ActiveBuffer], 0);

 whirl2.rotate += velocitytemp<<12;
 GsSortSprite(&whirl2, &OTable[ActiveBuffer], 0);
}



// Detect collisions:-
// Stop player going off the track
// Stop player going through track objects, such as trees or tunnels etc 
// Modifies the velocity/position of the player if collisions occure
void CollisionDetection(Player *play)
{
 long tempx=0,tempz=0, SegTemp, totaltemp;

 SegTemp = WorldData.Segment;
 //FntPrint("\nsegment= %d\n",SegTemp);

 // Track segment checking bounds etc
 switch(WorldData.Map[SegTemp])
  {
	case START:
	case ROADN:
	case ROADS:
	 {
	  tempx = play->Board.Coord.coord.t[0] - WorldData.Models[SegTemp].Coord.coord.t[0];

	  if (((tempx>-TRACK_EDGE_LIMIT)&&(tempx<-1000)) || ((tempx>1000)&&(tempx<TRACK_EDGE_LIMIT)))
	   {
		play->Velocity *= 0.96;
		SendDSPad(Pad0, 0, 0);
		
		// Low rumble because of the grass 
		SendDSPad(Pad0, 1, 75);
		//FntPrint("On the grass X");
	   }
      else if (tempx<=-TRACK_EDGE_LIMIT)
	   {
	    play->Board.Coord.coord.t[0] += 100;
		play->Man.Coord.coord.t[0] = play->Board.Coord.coord.t[0];
		play->Velocity *= 0.7;
		SendDSPad(Pad0, 0, 1);
        //FntPrint("           Off right\n");
	   }
      else if (tempx>=TRACK_EDGE_LIMIT)
	   {
	    play->Board.Coord.coord.t[0] -= 100;
		play->Man.Coord.coord.t[0] = play->Board.Coord.coord.t[0];
		play->Velocity *= 0.7;
		SendDSPad(Pad0, 0, 1);
        //FntPrint("            Off left\n");
	   }
      else 
	   {
	    // Turn off all vibrations
	    SendDSPad(Pad0, 0, 0);
		SendDSPad(Pad0, 1, 0);
       }

	  break;
	 }

	case ROADE:
	case ROADW:
	 {
	  tempz = play->Board.Coord.coord.t[2] - WorldData.Models[SegTemp].Coord.coord.t[2];

	  if (((tempz>-TRACK_EDGE_LIMIT)&&(tempz<-1000)) || ((tempz>1000)&&(tempz<TRACK_EDGE_LIMIT)))
	   {
		play->Velocity *= 0.96;
		SendDSPad(Pad0, 0, 0);
		// Low rumble because of the grass 
		SendDSPad(Pad0, 1, 75);
		//FntPrint("On the grass\n");
	   }
      else if (tempz<=-TRACK_EDGE_LIMIT)
	   {
	    play->Board.Coord.coord.t[2] += 100;
		play->Man.Coord.coord.t[2] = play->Board.Coord.coord.t[2];
		play->Velocity *= 0.7;
		SendDSPad(Pad0, 0, 1);
        //FntPrint("           Off right\n");
	   }
      else if (tempz>=TRACK_EDGE_LIMIT)
	   {
	    play->Board.Coord.coord.t[2] -= 100;
		play->Man.Coord.coord.t[2] = play->Board.Coord.coord.t[2];
		play->Velocity *= 0.7;
		SendDSPad(Pad0, 0, 1);
        //FntPrint("            Off left\n");
	   }
	  else 
	   {
	    // Turn off all vibrations
	    SendDSPad(Pad0, 0, 0);
		SendDSPad(Pad0, 1, 0);
       }
	  break;
	 }

	case CORNER1N:
	case CORNER1W:
	 {
	  tempx = WorldData.Models[SegTemp].Coord.coord.t[0] + 2250;
	  tempz = WorldData.Models[SegTemp].Coord.coord.t[2] - 2250;
	  tempx -= play->Board.Coord.coord.t[0];
	  tempz -= play->Board.Coord.coord.t[2];
	  totaltemp = tempx * tempx + tempz * tempz;

	  if (((totaltemp<1562500)&&(totaltemp>0)) || ((totaltemp>10562500)&&(totaltemp<20250000)))   // 1250 radius on each side
	   {
	    play->Velocity *= 0.96;
		SendDSPad(Pad0, 0, 0);
		// Low rumble because of the grass 
		SendDSPad(Pad0, 1, 75);
	    //FntPrint("On the grass Corner1\n");
	   }
      else if (totaltemp>=20250000)
       {
		play->Board.Coord.coord.t[0] += 100;
		play->Board.Coord.coord.t[2] -= 100;

		play->Man.Coord.coord.t[0] = play->Board.Coord.coord.t[0];
		play->Man.Coord.coord.t[2] = play->Board.Coord.coord.t[2];

		play->Velocity *= 0.7;
		SendDSPad(Pad0, 0, 1);
		//FntPrint("Over the outside of corner 1\n");
       }
      else if (totaltemp<=0)
       {
		play->Board.Coord.coord.t[0] -= 100;
		play->Board.Coord.coord.t[2] += 100;

		play->Man.Coord.coord.t[0] = play->Board.Coord.coord.t[0];
		play->Man.Coord.coord.t[2] = play->Board.Coord.coord.t[2];

		play->Velocity *= 0.7;
		SendDSPad(Pad0, 0, 1);
		//FntPrint("Over the inside of corner 1\n");
       }
      else 
	   {
	    // Turn off all vibrations
	    SendDSPad(Pad0, 0, 0);
		SendDSPad(Pad0, 1, 0);
       }
	  break;
	 }

	case CORNER2E:
	case CORNER2N:
	 {
	  tempx = WorldData.Models[SegTemp].Coord.coord.t[0] - 2250;
	  tempz = WorldData.Models[SegTemp].Coord.coord.t[2] - 2250;
	  tempx -= play->Board.Coord.coord.t[0];
	  tempz -= play->Board.Coord.coord.t[2];
	  totaltemp = tempx * tempx + tempz * tempz;

	  if (((totaltemp<1562500)&&(totaltemp>0)) || ((totaltemp>10562500)&&(totaltemp<20250000)))   // 1250 radius on each side
	   {
	    play->Velocity *= 0.96;
		SendDSPad(Pad0, 0, 0);
		// Low rumble because of the grass 
		SendDSPad(Pad0, 1, 75);

	    //FntPrint("On the grass Corner2\n");
	   }
      else if (totaltemp>=20250000)
       {
		play->Board.Coord.coord.t[0] -= 100;
		play->Board.Coord.coord.t[2] -= 100;

		play->Man.Coord.coord.t[0] = play->Board.Coord.coord.t[0];
		play->Man.Coord.coord.t[2] = play->Board.Coord.coord.t[2];

		play->Velocity *= 0.7;
		SendDSPad(Pad0, 0, 1);
		//FntPrint("Over the outside of corner 2\n");
       }
      else if (totaltemp<=0)
       {
		play->Board.Coord.coord.t[0] += 100;
		play->Board.Coord.coord.t[2] += 100;

		play->Man.Coord.coord.t[0] = play->Board.Coord.coord.t[0];
		play->Man.Coord.coord.t[2] = play->Board.Coord.coord.t[2];

		play->Velocity *= 0.7;
		SendDSPad(Pad0, 0, 1);
		//FntPrint("Over the inside of corner 2\n");
       }
      else 
	   {
	    // Turn off all vibrations
	    SendDSPad(Pad0, 0, 0);
		SendDSPad(Pad0, 1, 0);
       }
	  break;
	 }

	case CORNER3S:
	case CORNER3E:
	 {
	  tempx = WorldData.Models[SegTemp].Coord.coord.t[0] - 2250;
	  tempz = WorldData.Models[SegTemp].Coord.coord.t[2] + 2250;
	  tempx -= play->Board.Coord.coord.t[0];
	  tempz -= play->Board.Coord.coord.t[2];
	  totaltemp = tempx * tempx + tempz * tempz;

	  if (((totaltemp<1562500)&&(totaltemp>0)) || ((totaltemp>10562500)&&(totaltemp<20250000)))   // 1250 radius on each side
	   {
	    play->Velocity *= 0.96;
		SendDSPad(Pad0, 0, 0);
		// Low rumble because of the grass 
		SendDSPad(Pad0, 1, 75);
	    //FntPrint("On the grass Corner3\n");
	   }
      else if (totaltemp>=20250000)
       {
		play->Board.Coord.coord.t[0] -= 100;
		play->Board.Coord.coord.t[2] += 100;

		play->Man.Coord.coord.t[0] = play->Board.Coord.coord.t[0];
		play->Man.Coord.coord.t[2] = play->Board.Coord.coord.t[2];

		play->Velocity *= 0.7;
		SendDSPad(Pad0, 0, 1);
		//FntPrint("Over the outside of corner 3\n");
       }
      else if (totaltemp<=0)
       {
		play->Board.Coord.coord.t[0] += 100;
		play->Board.Coord.coord.t[2] -= 100;

		play->Man.Coord.coord.t[0] = play->Board.Coord.coord.t[0];
		play->Man.Coord.coord.t[2] = play->Board.Coord.coord.t[2];

		play->Velocity *= 0.7;
		SendDSPad(Pad0, 0, 1);
		//FntPrint("Over the inside of corner 3\n");
       }
      else 
	   {
	    // Turn off all vibrations
	    SendDSPad(Pad0, 0, 0);
		SendDSPad(Pad0, 1, 0);
       }
	  break;
	 }

	case CORNER4W:
	case CORNER4S:
	 {
	  tempx = WorldData.Models[SegTemp].Coord.coord.t[0] + 2250;
	  tempz = WorldData.Models[SegTemp].Coord.coord.t[2] + 2250;
	  tempx -= play->Board.Coord.coord.t[0];
	  tempz -= play->Board.Coord.coord.t[2];
	  	  totaltemp = tempx * tempx + tempz * tempz;

	  if (((totaltemp<1562500)&&(totaltemp>0)) || ((totaltemp>10562500)&&(totaltemp<20250000)))   // 1250 radius on each side
	   {
	    play->Velocity *= 0.96;
		SendDSPad(Pad0, 0, 0);
		// Low rumble because of the grass 
		SendDSPad(Pad0, 1, 75);
	    //FntPrint("On the grass Corner4\n");
	   }
      else if (totaltemp>=20250000)
       {
		play->Board.Coord.coord.t[0] += 100;
		play->Board.Coord.coord.t[2] += 100;

		play->Man.Coord.coord.t[0] = play->Board.Coord.coord.t[0];
		play->Man.Coord.coord.t[2] = play->Board.Coord.coord.t[2];

		play->Velocity *= 0.7;
		SendDSPad(Pad0, 0, 1);
		//FntPrint("Over the outside of corner 4\n");
       }
      else if (totaltemp<=0)
       {
		play->Board.Coord.coord.t[0] -= 100;
		play->Board.Coord.coord.t[2] -= 100;

		play->Man.Coord.coord.t[0] = play->Board.Coord.coord.t[0];
		play->Man.Coord.coord.t[2] = play->Board.Coord.coord.t[2];

		play->Velocity *= 0.7;
		SendDSPad(Pad0, 0, 1);
		//FntPrint("Over the inside of corner 4\n");
       }
      else 
	   {
	    // Turn off all vibrations
	    SendDSPad(Pad0, 0, 0);
		SendDSPad(Pad0, 1, 0);
       }
	  break;
	 }

	default:
	 {
	  break;
	 }
  }// end switch


// Check for collisions with the objects on the track, such as trees etc
switch(WorldData.Obj[SegTemp])
  {
	case CONEN:
	case ODDTREEN:
	case TREE1N:
	case TREE2N:
	case TREE3N:
	case TREE4N:
	 {
	  tempx = play->Board.Coord.coord.t[0] - WorldData.Objects[SegTemp].Coord.coord.t[0];
	  tempz = play->Board.Coord.coord.t[2] - WorldData.Objects[SegTemp].Coord.coord.t[2];
	  //FntPrint("OBJ N, x=%d z=%d\n", tempx, tempz);

	  if ((tempx>-COL_DISTANCE_OBJ)&&(tempx<COL_DISTANCE_OBJ)&&(tempz>-COL_DISTANCE_OBJ)&&(tempz<COL_DISTANCE_OBJ))
	   {
		play->Board.Coord.coord.t[2] -= 100;

		play->Man.Coord.coord.t[2] = play->Board.Coord.coord.t[2];
		play->Velocity *= 0.7;
		SendDSPad(Pad0, 0, 1);
	   }
	   break;
	  }


	case CONES:
	case ODDTREES:
	case TREE1S:
	case TREE2S:
	case TREE3S:
	case TREE4S:
	 {
	  tempx = play->Board.Coord.coord.t[0] - WorldData.Objects[SegTemp].Coord.coord.t[0];
	  tempz = play->Board.Coord.coord.t[2] - WorldData.Objects[SegTemp].Coord.coord.t[2];
	  //FntPrint("OBJ S, x=%d z=%d\n", tempx, tempz);

	  if ((tempx>-COL_DISTANCE_OBJ)&&(tempx<COL_DISTANCE_OBJ)&&(tempz>-COL_DISTANCE_OBJ)&&(tempz<COL_DISTANCE_OBJ))
	   {
		play->Board.Coord.coord.t[2] += 100;

		play->Man.Coord.coord.t[2] = play->Board.Coord.coord.t[2];
		play->Velocity *= 0.7;	
		SendDSPad(Pad0, 0, 1);
	   }
	   break;
	  }

    case CONEE:
	case ODDTREEE:
	case TREE1E:
	case TREE2E:
	case TREE3E:
	case TREE4E:
	 {
	  tempx = play->Board.Coord.coord.t[0] - WorldData.Objects[SegTemp].Coord.coord.t[0];
	  tempz = play->Board.Coord.coord.t[2] - WorldData.Objects[SegTemp].Coord.coord.t[2];
	  //FntPrint("OBJ E, x=%d z=%d\n", tempx, tempz);

	  if ((tempx>-COL_DISTANCE_OBJ)&&(tempx<COL_DISTANCE_OBJ)&&(tempz>-COL_DISTANCE_OBJ)&&(tempz<COL_DISTANCE_OBJ))
	   {
		play->Board.Coord.coord.t[0] -= 100;

		play->Man.Coord.coord.t[0] = play->Board.Coord.coord.t[0];
		play->Velocity *= 0.7;
		SendDSPad(Pad0, 0, 1);
	   }
	   break;
	  }

    case CONEW:
	case ODDTREEW:
	case TREE1W:
	case TREE2W:
	case TREE3W:
	case TREE4W:
	 {
	  tempx = play->Board.Coord.coord.t[0] - WorldData.Objects[SegTemp].Coord.coord.t[0];
	  tempz = play->Board.Coord.coord.t[2] - WorldData.Objects[SegTemp].Coord.coord.t[2];
	  //FntPrint("OBJ W, x=%d z=%d\n", tempx, tempz);

	  if ((tempx>-COL_DISTANCE_OBJ)&&(tempx<COL_DISTANCE_OBJ)&&(tempz>-COL_DISTANCE_OBJ)&&(tempz<COL_DISTANCE_OBJ))
	   {
		play->Board.Coord.coord.t[0] += 100;

		play->Man.Coord.coord.t[0] = play->Board.Coord.coord.t[0];
		play->Velocity *= 0.7;
		SendDSPad(Pad0, 0, 1);
	   }
	   break;
	 }

	case LMTUNNELX:
	 {
	  tempz = play->Board.Coord.coord.t[2] - WorldData.Objects[SegTemp].Coord.coord.t[2];
	  //FntPrint("LMTUNNELX, z=%d\n", tempz);

	  if (tempz<-(COL_DISTANCE_OBJ+200)) 
	   {
	    play->Board.Coord.coord.t[2] += 100;
		play->Man.Coord.coord.t[2] = play->Board.Coord.coord.t[2];
        play->Velocity *= 0.7;
		SendDSPad(Pad0, 0, 1);
	   }

      else if (tempz>(COL_DISTANCE_OBJ+200)) 
	   {
	    play->Board.Coord.coord.t[2] -= 100;
		play->Man.Coord.coord.t[2] = play->Board.Coord.coord.t[2];
		play->Velocity *= 0.7;
		SendDSPad(Pad0, 0, 1);
	   }
	 
	  break;
	 }

	case LMTUNNELZ:
	 {
	  tempx = play->Board.Coord.coord.t[0] - WorldData.Objects[SegTemp].Coord.coord.t[0];
	  //FntPrint("LMTUNNELX, x=%d\n", tempx);

	  if (tempx<-(COL_DISTANCE_OBJ+200)) 
	   {
	    play->Board.Coord.coord.t[0] += 100;
		play->Man.Coord.coord.t[0] = play->Board.Coord.coord.t[0];
        play->Velocity *= 0.7;
		SendDSPad(Pad0, 0, 1);
	   }

      else if (tempx>(COL_DISTANCE_OBJ+200)) 
	   {
	    play->Board.Coord.coord.t[0] -= 100;
		play->Man.Coord.coord.t[0] = play->Board.Coord.coord.t[0];
		play->Velocity *= 0.7;
		SendDSPad(Pad0, 0, 1);
	   }
	 
	  break;
	 }


  default:
	 {
	  break;
	 }
  }// end switch
  //FntPrint("tempx = %d tempz= %d\n",tempx, tempz);
}


void ControlTiming()
{ 
 long looptemp, result=0;

 // then not the first time run
 if (WorldData.Complete[0]!=FALSE)  EngineTime++;
 
 if ((WorldData.Complete[0]==TRUE) && (WorldData.Segment==0)) // posible end of one circuit
  {
   for (looptemp=0; looptemp<LEVEL1_SIZE; looptemp++)
    {
     result += WorldData.Complete[looptemp];
	 //printf("result = %d\n", result);
    }

   if (result == LEVEL1_SIZE) // one complete circuit finished
    {
     //printf("Finished one circuit\n");

	 if ((BestTime>EngineTime)||(BestTime==0))
	  { 
	   printf("New best time!\n");
	   BestTime=EngineTime;
	   EngineTime = 0;

	   for (looptemp=1; looptemp<LEVEL1_SIZE; looptemp++)
		 WorldData.Complete[looptemp] = 0;
	  } // endif
    } // endif
   //else printf("Did no get round fast enuf that time :)\n");


   } //endif
  //else FntPrint("Circuit not complete, go the right way around!\n");
    
} // end function

void Credits(void)
{
 long creditsloop=0;
 TMDModel nextpsx;

 InitTmd(&nextpsx, (u_long *)NEXTPSX_TMD, 40);
 SetTmdPos(&nextpsx, 0, 200, -4000);

 for (creditsloop=0; creditsloop<10000; creditsloop++)
  {
    PrepareScreen(); 
    DrawModel(&nextpsx);
    if ((creditsloop>0)&&(creditsloop<90))
     {
       DispText(&SmallFuture, "WELL THATS IT!", -55, -40);
	   RandomTMD(&nextpsx);
       if (creditsloop>45) 
	   {
	    DispText(&SmallFuture, "I HOPE U LIKE", -60, -10);
		DispText(&SmallFuture, " THE GAME", -30, 20);
       }
     }

    if ((creditsloop>90)&&(creditsloop<250))
     {
	   RandomTMD(&nextpsx);
       DispText(&SmallFuture, "GREETZ TO..", -45, -40);
       if (creditsloop>130)
	    {
		 DispText(&SmallFuture, "TRZ, BAROG, DANZ", -90, -20);
		 DispText(&SmallFuture, "GOBI, PETE, KVAKS", -90, 0);
		 DispText(&SmallFuture, "AVH, SONY..", -90, 0);
		 DispText(&SmallFuture, "AND ANYONE ELSE I", -90, 20);
         DispText(&SmallFuture, "THINK DESERVES ONE", -90, 40);
        }

     }

     if ((creditsloop>250)&&(creditsloop<2000))
     {
	   RandomTMD(&nextpsx);
       DispText(&SmallFuture, "NOW3D SIGNING OFF", -80, -40);
       if (creditsloop>280) DispText(&SmallFuture, "CYA", -80, 0);
     }

    FinishScreen();
  }

}


void RandomTMD(TMDModel *model)
{
 RotateModel(model, (rand() % 100), 0 , 0);
 RotateModel(model, 0 , 0, (rand() % 100));
 RotateModel(model, 0, (rand() % 100), 0);
}

