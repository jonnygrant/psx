#define VAGS_snd 4

unsigned long snd[] = {
	0x0,
	0x2570,
	0x4d50,
	0x6fa0,
	0x8ed0,
}; /* vag table from "snd.vab" */
