/* 3D Header file
	Copyright (c) now3d 2000.  All rights reserved
*/
#ifndef lib3d_h
#define lib3d_h


// 3D Object struct
typedef struct
{
 GsDOBJ2 Obj; // TMD model info
 GsCOORDINATE2 Coord; // Orientation of TMD
 SVECTOR Rotation;
 u_long Position;
}TMDModel;


#include "player.h"

#define FALSE 0
#define TRUE 1
#define SCREEN_WIDTH	320
#define SCREEN_HEIGHT 256
//#define SCREEN_HEIGHT 272
#define OTABLE_LENGTH 10

// Set the on screen position of the TIM
#define SetTimPos(im, nx, ny) (im)->x = (nx), (im)->y = (ny)

// Set TIM rgb values
#define SetTimRGB(im, nr, ng, nb) (im)->r = (nr), (im)->g = (ng), (im)->b = (nb)

// Set TIM scale
#define SetTimScale(im, nx, ny) (im)->scalex = (nx), (im)->scaley = (ny)

// Set TIM u/v
#define SetTimUV(im, nu, nv) (im)->u = (nu), (im)->v = (nv)

// Set TIM w/h
#define SetTimWH(im, nw, nh) (im)->w = (nw), (im)->h = (nh)

// Set the position of the TMD
#define SetTmdPos(tmd, nx, ny, nz) (tmd)->Coord.coord.t[0] = (nx), \
											  (tmd)->Coord.coord.t[1] = (ny), \
											  (tmd)->Coord.coord.t[2] = (nz), \
											  (tmd)->Coord.flg = 0

// Set the colour of the Fonts
#define SetFontRGB(fnt, nr, ng, nb) \
	 (fnt)->Image.r = (nr), \
	 (fnt)->Image.g = (ng), \
    (fnt)->Image.b = (nb)


// Set the position of the TMD  X
#define SetTmdPosX(tmd, nx) (tmd)->Coord.coord.t[0] += (nx), \
											  (tmd)->Coord.flg = 0

// Set the position of the TMD  Y
#define SetTmdPosY(tmd, ny) (tmd)->Coord.coord.t[1] += (ny), \
											  (tmd)->Coord.flg = 0

// Set the position of the TMD  Z
#define SetTmdPosZ(tmd, nz) (tmd)->Coord.coord.t[2] += (nz), \
											  (tmd)->Coord.flg = 0

// Reset the matrix to Identity 4096 and 0 (conrad)
#define ResetMatrix(m) \
		m[0][0]=m[1][1]=m[2][2]=4096, \
		m[0][1]=m[0][2]=m[1][0]=m[1][2]=m[2][0]=m[2][1]=0



#define BitSet(one, two) (*(one) = (*(one)) | (two))

// corners are 3x3 road is 3x1
#define TILESIZE 1500
#define LEVEL1_SIZE 62
#define SEGMENT_DEPTH 62



// Array of 2 OT's with space for the OTable length defined
// GsOT is the headers, GsOT_TAG is the Ordering structure
GsOT     OTable[2];
GsOT_TAG OT_TAGarray[2][1<<OTABLE_LENGTH];
PACKET   PacketMemory[2][128000];
DRAWENV Draw[2];
DISPENV Disp[2];
int ActiveBuffer;


typedef struct
{
 char Map[LEVEL1_SIZE];  // the index to the circuit
 TMDModel Models[LEVEL1_SIZE];  // the actual instances of the track segments

 char Obj[LEVEL1_SIZE];  // objects on each track segment
 TMDModel Objects[LEVEL1_SIZE]; // the actual instances of the track objects

 u_long Segment;           // which tile the model is over now
 TMDModel *RefObject;      // used when calculating which track tiles to draw									
                           // the reference point to take the view point from
 u_char Complete[LEVEL1_SIZE];  // Flag to show if each segment complete
 
}WorldLevel;

#define CHARS 65

typedef struct
{
 GsSPRITE Image;
 u_long u;
 u_long v;
 u_long Columns;
 char CharOrder[CHARS];
} FontTexture;



// Prototypes
void Init3DGfx();
void InitTim(GsSPRITE *Image, u_long ImageAddrs);
void PrepareScreen();
void FinishScreen();
void InitTmd(TMDModel *Obj, u_long *ModelAddrs, u_long Pos);
void InitLight(GsF_LIGHT *newlight, int Lnum, int nx, int ny, int nz, int nr, int ng, int nb);
void InitView(GsRVIEW2 *ViewP, int Dist, int npx, int npy, int npz, int nrx, int nry, int nrz, int nup);
void InitTrackerView(GsRVIEW2 *ViewP, TMDModel *Obj, int Dist, int npx, int npy,
							int npz, int nrx, int nry, int nrz, int nup);
void DrawModel(TMDModel *Obj);
void RotateModel(TMDModel *Obj, int nx, int ny, int nz);
void RotateModel2(TMDModel *Obj, long ny);


// prototypes for Font functions
void InitFont(FontTexture *FntImage, u_long TexAddrs, char *Order, char w, char h, char c, int Scalex, int Scaley);
void DispText(FontTexture *FntImage, char *String, int xpos, int ypos);


// 3D world functions
void InitWorldMap(WorldLevel *level);
void Init3DWorld(WorldLevel *level, Player *play);
void DrawWorld(WorldLevel *level);
void UpdateSegment(WorldLevel *level);


#endif
