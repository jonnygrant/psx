/* 3D Libary functions
	Copyright (c) now3d 2000.  All rights reserved
*/

#include <sys/types.h>
#include <libgte.h>
#include <libgpu.h>
#include <libgs.h>

#include "addrs.h"
#include "3d.h"
#include "levels.h"
#include "track.h"

//#define TRACKDEBUG

long VerticalSync=0, ScreenMode;

// Init the 2D gfx sub system
void Init3DGfx(void)
{
// From napalm, check ROM for Europe
 if (*(char *)0xbfc7ff52=='E')
  {
	SetVideoMode(1); // PAL
	printf("PAL Mode auto selected\n");

	ScreenMode=TRUE; // PAL
	// Set resolution and double buffer in GPU
	GsInitGraph(SCREEN_WIDTH, SCREEN_HEIGHT, GsNONINTER|GsOFSGPU, 1, 0);

	// Define double buffer, 1(0,0) and 2(0,SCREEN_HEIGHT)
	// position in VRAM
	GsDefDispBuff(0, 0, 0, SCREEN_HEIGHT);

	// load fonts
	FntLoad(960, 256);
	FntOpen(-140, -120, 280, 260, 0, 512);
  }
 else
  {
	SetVideoMode(0); // NTSC
	printf("NTSC Mode auto selected\n");

	ScreenMode=FALSE; // NTSC
	// Set resolution and double buffer in GPU
	GsInitGraph(SCREEN_WIDTH, SCREEN_HEIGHT, GsNONINTER|GsOFSGPU, 1, 0);

	// Define double buffer, 1(0,0) and 2(0,SCREEN_HEIGHT) position in VRAM
	GsDefDispBuff(0, 0, 0, SCREEN_HEIGHT);

	// load fonts
	FntLoad(960, 256);
	FntOpen(-140, -110, 280, 260, 0, 512);
  }

 // Set OT length for each buffer
 OTable[0].length = OTABLE_LENGTH;
 OTable[1].length = OTABLE_LENGTH;

 // Set org to start of TAG arrays
 OTable[0].org = OT_TAGarray[0];
 OTable[1].org = OT_TAGarray[1];

 // Clear OT
 GsClearOt(0, 0, &OTable[0]);
 GsClearOt(0, 0, &OTable[1]);

// Init 3D hardware
 GsInit3D();
 printf("End Init3DGfx()\n");
}


// Prepare the OT and VRAM for new frame
void PrepareScreen(void)
{
// Get the currently selected display buffer
ActiveBuffer = GsGetActiveBuff();

// Sets up the workspace packet dubble buffer area
GsSetWorkBase((PACKET*)PacketMemory[ActiveBuffer]);
GsClearOt(0, 10000, &OTable[ActiveBuffer]);    // 10,000 average z value
}

// Call at end of draw to Ordering Table, finishes the frame
void FinishScreen(void)
{
 DrawSync(0);  // Wait till the GPU has finished

 // Get the vsync and Display it, if it is below the SCREEN_WIDTH (320)
 // Then that is fine, but if above SCREEN_WIDTH then it needs optimising
 VerticalSync=VSync(2);
 //FntPrint("Sync: %d\n", VerticalSync);
 FntFlush(-1);

 // GsSwap has to be called at the beginning of a VSync()
 GsSwapDispBuff();  // swap display buffer

 // Clears screen to colour (0,0,60) and sorts OT ready for displaying, blue
 GsSortClear(0, 0, 40, &OTable[ActiveBuffer]);
 GsDrawOt(&OTable[ActiveBuffer]);  // Draw OT contents to VRAM
}


// Initalise the image after being loaded into VRAM
// Parameters: Image Pointer to GsSPRITE struct
// FILE_TIM #defined address
void InitTim(GsSPRITE *Image, u_long ImageAddrs)
{
GsIMAGE TimImage;
int ImageType, WidthCompression;

// Get attributes of the tim in memory
GsGetTimInfo((u_long *)(ImageAddrs+4), &TimImage);

ImageType = TimImage.pmode&3;
switch (ImageType)
 {
  case 0: {WidthCompression=4; break;}
  case 1: {WidthCompression=2; break;}
  case 2: {WidthCompression=1; break;}
  case 3: {printf("24bit tim's unsuported\n"); break;}
 }

// Set the attribute colour depth
Image->attribute = (ImageType<<24);

Image->w = TimImage.pw * WidthCompression;
Image->h = TimImage.ph;

// Get texture page
Image->tpage = GetTPage(ImageType, 0, TimImage.px, TimImage.py);

// Offset in vram
Image->u = (TimImage.px%64) * WidthCompression;
Image->v = TimImage.py%256;

// set clut position if 4/8 bit
if (ImageType < 2)
 {
  Image->cx = TimImage.cx;
  Image->cy = TimImage.cy;
 }

// Set all brightness to midvalue 128
Image->r = 128;
Image->g = 128;
Image->b = 128;

// Set scale/rotate = 4096 GPU equiv of 1
Image->scalex = 4096;
Image->scaley = 4096;
Image->rotate = 0;

// Set the center of the image (m)
Image->mx = TimImage.pw*WidthCompression/2;
Image->my = TimImage.ph/2;
}

// Init the font TIM
// Parameters: Pointer to FontTexture struct
// FILE_TIM #defined address
// Order of chars
// width, height, columns
// scale x,y  (1 psx unit=4096)
void InitFont(FontTexture *FntImage, u_long TexAddrs, char *Order, char w, char h, char c, int Scalex, int Scaley)
{
 // set the order of the characters
 strcpy(FntImage->CharOrder, Order);
 //printf("\nOrder = %s\n", Order);

 // Initalise the texture and set the scale ratio
 InitTim(&FntImage->Image, TexAddrs);
 SetTimScale(&FntImage->Image, Scalex, Scaley);

 // Set the size of each character and coloumns
 SetTimWH(&FntImage->Image, w, h);
 FntImage->Columns = c;

 FntImage->u = FntImage->Image.u;
 FntImage->v = FntImage->Image.v;
 //printf("\nInitalised the width height etc\n");
}


// Display the text in the correct font at the correct position
// Parameters: Pointer to FontTexture struct
// String, to display
// x,y, pos is for the 1st char!
void DispText(FontTexture *FntImage, char *String, int xpos, int ypos)
{
 u_long u=0, v=0, newxpos=0,x=0, y=0;

 while(String[x] != 0)
 {
  //printf("#=%c x=%d\n",String[x],x);
	for(y=0; y<CHARS; y++)
	 {
	  if (FntImage->CharOrder[y] == String[x])
		{
		 //printf("Found char = %c\n",FntImage->CharOrder[y]);

		 // Draw text in one line
		 newxpos = xpos + x * FntImage->Image.w;
		 SetTimPos(&FntImage->Image, newxpos, ypos );
		 //printf("newxpos = %d\n",newxpos);

		 u = FntImage->u + (y % FntImage->Columns) * FntImage->Image.w;
		 v = FntImage->v + (y / FntImage->Columns) * FntImage->Image.w;

		 //printf("column #= %d\n",(y % FntImage->Columns));
		 //printf("row #= %d\n",(y / FntImage->Columns));

		 SetTimUV(&FntImage->Image, u, v );

		 // Add to OT
		 GsSortSprite(&FntImage->Image, &OTable[ActiveBuffer], 0);

		}
	 }// end y for loop

  x++;
 }// end while loop
}


// Initalise the model after being loaded into RAM
// Parameter: Pointer to TMDModel Obj
// ModelAddrs pointer to FILE_TMD
// Pos, level to sort at in the Ordering Table
void InitTmd(TMDModel *Obj, u_long *ModelAddrs, u_long Pos)
{
 // Ignore the model id
 GsMapModelingData((u_long*)(ModelAddrs+1));

 // Link TMD with struct
 GsLinkObject4((u_long)(ModelAddrs+3), &Obj->Obj, 0);

 // Init TMD to world 0,0,0
 GsInitCoordinate2(WORLD, &Obj->Coord);

 Obj->Obj.coord2 = &Obj->Coord;
 Obj->Obj.attribute = 0;

 Obj->Position = Pos; 

 Obj->Rotation.vx = 0;
 Obj->Rotation.vy = 0;
 Obj->Rotation.vz = 0;

 // Set flag to make GTE re-compute
 Obj->Coord.flg = 0;

 //printf("\nEnd InitTmd();");
}

// Init Light source
// Parameters: Pointer to newlight
// Lnum, light number
// nx, ny, nz, position of the new light source
// nr, ng, nb, colour of the light RGB
void InitLight(GsF_LIGHT *newlight, int Lnum, int nx, int ny, int nz, int nr, int ng, int nb)
{
// The direction of the light
 newlight->vx = nx;
 newlight->vy = ny;
 newlight->vz = nz;

// Colour of light, if all the same then white light
 newlight->r = nr;
 newlight->g = ng;
 newlight->b = nb;

 // Lnum = Light source number, 0 or 1 or 2
 GsSetFlatLight(Lnum, newlight);

 printf("End InitLight();\n");
}

// Init fixed viewpoint
// Parameters: Pointer to GsRVIEW2 struct
// Dist, distance from viewpoint
// npx, npy, npz, new viewpoint co-ords linked to super
// nrx, nry, nrz, new reference points linked to super
// nup, viewpoint twist on the z axis
void InitView(GsRVIEW2 *ViewP, int Dist, int npx, int npy, int npz, int nrx, int nry, int nrz, int nup)
{
 GsSetProjection(Dist);

// View Point coords
 ViewP->vpx = npx;
 ViewP->vpy = npy;
 ViewP->vpz = npz;

// Reference point coords
 ViewP->vrx = nrx;
 ViewP->vry = nry;
 ViewP->vrz = nrz;

// Set which way is up
 ViewP->rz=-nup;

// Set the origin of the coord system in this case the world
 ViewP->super = WORLD;
// Activate view
 GsSetRefView2(ViewP);
 GsSetLightMode(0);

 printf("End InitView();\n");
}

// Init 3D tracking viewpoint
// Parameters: Pointer to GsRVIEW2 struct
// Dist, distance from viewpoint
// npx, npy, npz, new viewpoint co-ords linked to super
// nrx, nry, nrz, new reference points linked to super
// nup, viewpoint twist on the z axis
void InitTrackerView(GsRVIEW2 *ViewP, TMDModel *Obj, int Dist, int npx, int npy, int npz, int nrx, int nry, int nrz, int nup)
{
 GsSetProjection(Dist);

// View Point coords
 ViewP->vpx = npx;
 ViewP->vpy = npy;
 ViewP->vpz = npz;

// Reference point coords
 ViewP->vrx = nrx;
 ViewP->vry = nry;
 ViewP->vrz = nrz;

// Set which way is up
 ViewP->rz=-nup;

// Set the origin of the coord system in this case the world
 ViewP->super = &Obj->Coord;

 GsSetLightMode(0);

 //printf("\nEnd InitTrackerView();");
}

// Add the model to the Ordering Table
// Parameter: Pointer to TMDModel
void DrawModel(TMDModel *Obj)
{
 MATRIX  LocalScreen, LocalWorld;

// Get World and Local screen matrices
 GsGetLws(Obj->Obj.coord2, &LocalWorld, &LocalScreen);

// Set local matrix so GTE can calc stuff
 GsSetLightMatrix(&LocalWorld);

// Set Screen matix for perspective etc
 GsSetLsMatrix(&LocalScreen);

// Add object to ordering table
 GsSortObject4(&Obj->Obj, &OTable[ActiveBuffer], Obj->Position, (u_long *)0x1f800000);
}

// Rotate model
// Parameter: Pointer to TMDModel
// nx, ny, nz, new position
void RotateModel(TMDModel *Obj, int nx, int ny, int nz)
{
 MATRIX MatRot;
 SVECTOR Rotation;

 Rotation.vx = nx;
 Rotation.vy = ny;
 Rotation.vz = nz;

 // Create matrix from rotation params
 RotMatrix(&Rotation, &MatRot);

 MulMatrix0(&Obj->Coord.coord, &MatRot, &Obj->Coord.coord);

 // Set flag to make GTE re-compute
 Obj->Coord.flg = 0;
}

// Rotate direction and model in the y-axis
// Parameter: Pointer to TMDModel
// ny, new y-axis position
void RotateModel2(TMDModel *Obj, long ny)
{
 // reset matrix to identity
 ResetMatrix(Obj->Coord.coord.m);

 Obj->Rotation.vy+=ny;

 // loop around as 360 degrees = 4096 psx degrees
 if (Obj->Rotation.vy > 4096) Obj->Rotation.vy-=4096;
 else if (Obj->Rotation.vy < 0) Obj->Rotation.vy +=4096;
 if (Obj->Rotation.vy!=0)
  {
	RotMatrix(&Obj->Rotation, &Obj->Coord.coord);
	Obj->Coord.flg=0;
  }
}


// 3D World functions

// Copy Map into World level struct
//Paramenters: WorldLevel struct
void InitWorldMap(WorldLevel *level)
{
 int loop;
 // copy data into struct
  for (loop=0; loop<LEVEL1_SIZE; loop++)
  {
	level->Map[loop] = Level1[loop];
	level->Obj[loop] = Level1Objects[loop];
	level->Complete[loop] = FALSE;  // set each segment to NOT completed
  }
  // How many segments used?
  printf("World map segment size = %d\n", sizeof(Level1));
  printf("End InitWorldMap();\n");
}

// Set up positions of all objects
// Parameters: WorldLevel Pointer
// Player, Pointer
void Init3DWorld(WorldLevel *level, Player *play)
{
 //register int *loop=(int *)0x1f800000;
 register int loop=0, x=1, z=1, centrex, centrez;

 // Copy data into struct
 InitWorldMap(level);

 level->RefObject = &play->Man;
 level->Segment =0;
 // set up appropriate models
  for (loop=0; loop<LEVEL1_SIZE; loop++)
	{
	 //printf("\nLevel1[%d] obj=%d  ",loop, level->Map[loop]);

		// track segment position setup
		switch(level->Map[loop])
		 {
		  case CORNER1N:
			 {
			  //printf(" CORNER 1 North");
			  InitTmd(&level->Models[loop], (u_long *)CORNER_TMD, 100);
			  z+= TILESIZE;
			  centrex=x;
			  centrez=z;
			  SetTmdPos(&level->Models[loop], x, 0, z);
			  x+= TILESIZE*2;
			  //printf(" z= %d  x= %d",z ,x);
			  break;
			 }

		  case CORNER1W:
			 {
			  //printf(" CORNER 1 North");
			  InitTmd(&level->Models[loop], (u_long *)CORNER_TMD, 100);
			  x-= TILESIZE;
			  centrex=x;
			  centrez=z;
			  SetTmdPos(&level->Models[loop], x, 0, z);
			  z-= TILESIZE*2;
			  //printf(" z= %d  x= %d",z ,x);
			  break;
			 }

		  case CORNER2E:
			 {
			  #ifdef TRACKDEBUG
			  printf("Rotate %d",loop);
			  printf(" CORNER 2 East\n");
			  #endif
			  InitTmd(&level->Models[loop], (u_long *)CORNER_TMD, 100);
			  RotateModel2(&level->Models[loop], 1024);
			  x+= TILESIZE;
			  centrex=x;
			  centrez=z;
			  SetTmdPos(&level->Models[loop], x, 0, z);
			  z-= TILESIZE*2;
			  //printf(" z= %d  x= %d",z ,x);

			  break;
			 }

		  case CORNER2N:
			 {
			  //printf(" CORNER 2 North");
			  InitTmd(&level->Models[loop], (u_long *)CORNER_TMD, 100);
			  RotateModel2(&level->Models[loop], 1024);
			  z+= TILESIZE;
           centrex=x;
			  centrez=z;
			  SetTmdPos(&level->Models[loop], x, 0, z);
			  x-= TILESIZE*2;
			  //printf(" z= %d  x= %d",z ,x);
			  break;
			 }

		  case CORNER3E:
			 {
			  //printf(" CORNER 3 East");
			  InitTmd(&level->Models[loop], (u_long *)CORNER_TMD, 100);
			  RotateModel2(&level->Models[loop], 2048);
			  x+= TILESIZE;
           centrex=x;
			  centrez=z;
			  SetTmdPos(&level->Models[loop], x, 0, z);
			  z+= TILESIZE*2;
			  //printf(" z= %d  x= %d",z ,x);
			  break;
			 }

			case CORNER3S:
			 {
			  //printf(" CORNER 3 south");
			  InitTmd(&level->Models[loop], (u_long *)CORNER_TMD, 100);
			  RotateModel2(&level->Models[loop], 2048);
			  z-= TILESIZE;
			  centrex=x;
			  centrez=z;
			  SetTmdPos(&level->Models[loop], x, 0, z);
			  x-= TILESIZE*2;
			  //printf(" z= %d  x= %d",z ,x);
			  break;
			 }

		  case CORNER4S:
			 {
			  //printf(" CORNER 4 South");
			  InitTmd(&level->Models[loop], (u_long *)CORNER_TMD, 100);
			  RotateModel2(&level->Models[loop], 3072);
			  z-= TILESIZE;
			  centrex=x;
			  centrez=z;
			  SetTmdPos(&level->Models[loop], x, 0, z);
			  x+= TILESIZE*2;
			  //printf(" z= %d  x= %d",z ,x);
			  break;
			 }

		  case CORNER4W:
			 {
			  //printf(" CORNER 4 West");
			  InitTmd(&level->Models[loop], (u_long *)CORNER_TMD, 100);
           RotateModel2(&level->Models[loop], 3072);
			  x-= TILESIZE;
           centrex=x;
			  centrez=z;
			  SetTmdPos(&level->Models[loop], x, 0, z);
			  z+= TILESIZE*2;
			  //printf(" z= %d  x= %d",z ,x);
			  break;
			 }

		  case START:
			 {
			  //printf(" ROAD Start");
			  InitTmd(&level->Models[loop], (u_long *)START_TMD, 100);
			  SetTmdPos(&level->Models[loop], x, 0, z);
			  //printf(" z= %d",z);
           centrex=x;
			  centrez=z;
			  z += TILESIZE;
			  break;
			 }


		  case ROADN:
			 {
			  //printf(" ROAD North");
			  InitTmd(&level->Models[loop], (u_long *)ROADZ_TMD, 100);
			  SetTmdPos(&level->Models[loop], x, 0, z);
			  //printf(" z= %d",z);
           centrex=x;
			  centrez=z;
			  z += TILESIZE;
			  break;
			 }

		  case ROADS:
			 {
			  //printf(" ROAD South");
			  InitTmd(&level->Models[loop], (u_long *)ROADZ_TMD, 100);
			  SetTmdPos(&level->Models[loop], x, 0, z);
			  RotateModel2(&level->Models[loop], 2048);
			  //printf(" z= %d",z);
           centrex=x;
			  centrez=z;
			  z -= TILESIZE;
			  break;
			 }

		  case ROADE:
			 {
			  //printf(" ROAD East");
			  InitTmd(&level->Models[loop], (u_long *)ROADZ_TMD, 100);
			  SetTmdPos(&level->Models[loop], x, 0, z);
			  RotateModel2(&level->Models[loop], 1024);
			  //printf(" x= %d",x);
           centrex=x;
			  centrez=z;
			  x += TILESIZE;
			  break;
			 }

		  case ROADW:
			 {
			  //printf(" ROAD West");
			  InitTmd(&level->Models[loop], (u_long *)ROADZ_TMD, 100);
			  SetTmdPos(&level->Models[loop], x, 0, z);
           RotateModel2(&level->Models[loop], 3072);
			  //printf(" x= %d",x);
           centrex=x;
			  centrez=z;
			  x -= TILESIZE;
			  break;
			 }
		  } //end switch track segment


		// Set up the objects on each track segment
		switch(level->Obj[loop])
		 {
		  case NONE:
			 {
			  //printf("\n%d is NONE %d", loop, level->Obj[loop]);
			  break;
			 }

		  case CONEN:
			 {
			  //printf("\n%d is CONEN %d", loop, level->Obj[loop]);
			  InitTmd(&level->Objects[loop], (u_long *)CONE_TMD, 40);
			  //if (level->Map[loop]==
			  SetTmdPos(&level->Objects[loop], centrex, -50, centrez+1500);
			  break;
			 }

		  case CONES:
			 {
			  //printf("\n%d is CONES %d", loop, level->Obj[loop]);
			  InitTmd(&level->Objects[loop], (u_long *)CONE_TMD, 40);
			  SetTmdPos(&level->Objects[loop], centrex, -50, centrez-1500);
			  break;
			 }

		  case CONEE:
			 {
			  //printf("\n%d is CONEE %", loop, level->Obj[loop]);
			  InitTmd(&level->Objects[loop], (u_long *)CONE_TMD, 40);
			  SetTmdPos(&level->Objects[loop], centrex+1500, -50, centrez);
			  break;
			 }

		  case CONEW:
			 {
			  //printf("\n%d is CONEW %", loop, level->Obj[loop]);
			  InitTmd(&level->Objects[loop], (u_long *)CONE_TMD, 40);
			  SetTmdPos(&level->Objects[loop], centrex-1500, -50, centrez);
			  break;
			 }

		  case CONENE:
			 {
			  //printf("\n%d is CONENE %", loop, level->Obj[loop]);
			  InitTmd(&level->Objects[loop], (u_long *)CONE_TMD, 40);
			  SetTmdPos(&level->Objects[loop], centrex+1800, -50, centrez+1800);
			  break;
			 }

		  case CONENW:
			 {
			  //printf("\n%d is CONENW %", loop, level->Obj[loop]);
			  InitTmd(&level->Objects[loop], (u_long *)CONE_TMD, 40);
			  SetTmdPos(&level->Objects[loop], centrex-1800, -50, centrez+1800);
			  break;
			 }

		  case CONESW:
			 {
			  //printf("\n%d is CONESW %", loop, level->Obj[loop]);
			  InitTmd(&level->Objects[loop], (u_long *)CONE_TMD, 40);
			  SetTmdPos(&level->Objects[loop], centrex-1800, -50, centrez-1800);
			  break;
			 }
		  case CONESE:
			 {
			  //printf("\n%d is CONESE %", loop, level->Obj[loop]);
			  InitTmd(&level->Objects[loop], (u_long *)CONE_TMD, 40);
			  SetTmdPos(&level->Objects[loop], centrex+1800, -50, centrez-1800);
			  break;
			 }


		  case TREE2N:
			 {
			  //printf("\n%d is TREE2N %d", loop, level->Obj[loop]);
			  InitTmd(&level->Objects[loop], (u_long *)TREE2_TMD, 40);
			  SetTmdPos(&level->Objects[loop], centrex, -50, centrez+1500);
			  break;
			 }

		  case TREE2S:
			 {
			  //printf("\n%d is TREE2S %d", loop, level->Obj[loop]);
			  InitTmd(&level->Objects[loop], (u_long *)TREE2_TMD, 40);
			  SetTmdPos(&level->Objects[loop], centrex, -50, centrez-1500);
			  break;
			 }

		  case TREE2E:
			 {
			  //printf("\n%d is TREE2E %d", loop, level->Obj[loop]);
			  InitTmd(&level->Objects[loop], (u_long *)TREE2_TMD, 40);
			  SetTmdPos(&level->Objects[loop], centrex+1500, -50, centrez);
			  break;
			 }
		  case TREE2W:
			 {
			  //printf("\n%d is TREE2W %d", loop, level->Obj[loop]);
			  InitTmd(&level->Objects[loop], (u_long *)TREE2_TMD, 40);
			  SetTmdPos(&level->Objects[loop], centrex-1500, -50, centrez);
			  break;
			 }


		  case TREE3N:
			 {
			  //printf("\n%d is TREE3N %d", loop, level->Obj[loop]);
			  InitTmd(&level->Objects[loop], (u_long *)TREE3_TMD, 40);
			  SetTmdPos(&level->Objects[loop], centrex, -50, centrez+1500);
			  RotateModel2(&level->Objects[loop], 1024);
			  break;
			 }

		  case TREE3S:
			 {
			  //printf("\n%d is TREE3S %d", loop, level->Obj[loop]);
			  InitTmd(&level->Objects[loop], (u_long *)TREE3_TMD, 40);
			  SetTmdPos(&level->Objects[loop], centrex, -50, centrez-1500);
			  RotateModel2(&level->Objects[loop], 1024);
			  break;
			 }

		  case TREE3E:
			 {
			  //printf("\n%d is TREE3E %d", loop, level->Obj[loop]);
			  InitTmd(&level->Objects[loop], (u_long *)TREE3_TMD, 40);
			  SetTmdPos(&level->Objects[loop], centrex+1500, -50, centrez);
			  break;
			 }
		  case TREE3W:
			 {
			  //printf("\n%d is TREE3W %d", loop, level->Obj[loop]);
			  InitTmd(&level->Objects[loop], (u_long *)TREE3_TMD, 40);
			  SetTmdPos(&level->Objects[loop], centrex-1500, -50, centrez);
			  break;
			 }


		  case TREE4N:
			 {
			  //printf("\n%d is TREE4N %d", loop, level->Obj[loop]);
			  InitTmd(&level->Objects[loop], (u_long *)TREE4_TMD, 40);
			  SetTmdPos(&level->Objects[loop], centrex, -50, centrez+1500);
			  break;
			 }

		  case TREE4S:
			 {
			  //printf("\n%d is TREE4S %d", loop, level->Obj[loop]);
			  InitTmd(&level->Objects[loop], (u_long *)TREE4_TMD, 40);
			  SetTmdPos(&level->Objects[loop], centrex, -50, centrez-1500);
			  break;
			 }

		  case TREE4E:
			 {
			  //printf("\n%d is TREE4E %d", loop, level->Obj[loop]);
			  InitTmd(&level->Objects[loop], (u_long *)TREE4_TMD, 40);
			  SetTmdPos(&level->Objects[loop], centrex+1500, -50, centrez);
			  break;
			 }
		  case TREE4W:
			 {
			  //printf("\n%d is TREE4W %d", loop, level->Obj[loop]);
			  InitTmd(&level->Objects[loop], (u_long *)TREE4_TMD, 40);
			  SetTmdPos(&level->Objects[loop], centrex-1500, -50, centrez);
			  break;
			 }


		  case ODDTREEN:
			 {
			  //printf("\n%d is ODDTREEN %d", loop, level->Obj[loop]);
			  InitTmd(&level->Objects[loop], (u_long *)ODDTREE_TMD, 40);
			  SetTmdPos(&level->Objects[loop], centrex, -50, centrez+1500);
			  break;
			 }
		  case ODDTREES:
			 {
			  //printf("\n%d is ODDTREES %d", loop, level->Obj[loop]);
			  InitTmd(&level->Objects[loop], (u_long *)ODDTREE_TMD, 40);
			  SetTmdPos(&level->Objects[loop], centrex, -50, centrez-1500);
			  break;
			 }
		  case ODDTREEE:
			 {
			  //printf("\n%d is ODDTREEN %d", loop, level->Obj[loop]);
			  InitTmd(&level->Objects[loop], (u_long *)ODDTREE_TMD, 40);
			  SetTmdPos(&level->Objects[loop], centrex+1500, -50, centrez);
			  break;
			 }
		  case ODDTREEW:
			 {
			  //printf("\n%d is ODDTREEN %d", loop, level->Obj[loop]);
			  InitTmd(&level->Objects[loop], (u_long *)ODDTREE_TMD, 40);
			  SetTmdPos(&level->Objects[loop], centrex-1500, -50, centrez);
			  break;
			 }


		  case STADIUMN:
			 {
			  //printf("\n%d is STADIUMN %d", loop, level->Obj[loop]);
			  InitTmd(&level->Objects[loop], (u_long *)STADIUM_TMD, 40);
			  SetTmdPos(&level->Objects[loop], centrex, 0, centrez+2160);
			  RotateModel2(&level->Objects[loop], 1024);
			  break;
			 }
		  case STADIUMS:
			 {
			  //printf("\n%d is STADIUMS %d", loop, level->Obj[loop]);
			  InitTmd(&level->Objects[loop], (u_long *)STADIUM_TMD, 40);
			  SetTmdPos(&level->Objects[loop], centrex, 0, centrez-2160);
			  RotateModel2(&level->Objects[loop], 3072);
			  break;
			 }
		  case STADIUME:
			 {
			  //printf("\n%d is STADIUME %d", loop, level->Obj[loop]);
			  InitTmd(&level->Objects[loop], (u_long *)STADIUM_TMD, 40);
			  SetTmdPos(&level->Objects[loop], centrex+2160, 0, centrez);
			  RotateModel2(&level->Objects[loop], 2048);
			  break;
			 }
		  case STADIUMW:
			 {
			  //printf("\n%d is STADIUMW %d", loop, level->Obj[loop]);
			  InitTmd(&level->Objects[loop], (u_long *)STADIUM_TMD, 40);
			  SetTmdPos(&level->Objects[loop], centrex-2160, 0, centrez);
			  break;
			 }

		  case PSTARTZ:
			 {
			  //printf("\n%d is PSTARTZ%d", loop, level->Obj[loop]);
			  InitTmd(&level->Objects[loop], (u_long *)PSTART_TMD, 40);
			  SetTmdPos(&level->Objects[loop], centrex, 0, centrez);
			  break;
			 }


		  case TUNNELX:
			 {
			  //printf("\n%d is TUNNLEX %d", loop, level->Obj[loop]);
			  InitTmd(&level->Objects[loop], (u_long *)TUNNEL_TMD, 40);
           RotateModel2(&level->Objects[loop], 1024);
			  SetTmdPos(&level->Objects[loop], centrex, -50, centrez);
			  break;
			 }

		  case LMTUNNELX:
			 {
			  //printf("\n%d is LMTUNNLEX %d", loop, level->Obj[loop]);
			  InitTmd(&level->Objects[loop], (u_long *)LMTUNNEL_TMD, 40);
           RotateModel2(&level->Objects[loop], 1024);
			  SetTmdPos(&level->Objects[loop], centrex, -50, centrez);
			  break;
			 }

		  case LMTUNNELZ:
			 {
			  //printf("\n%d is LMTUNNLEX %d", loop, level->Obj[loop]);
			  InitTmd(&level->Objects[loop], (u_long *)LMTUNNEL_TMD, 40);
			  SetTmdPos(&level->Objects[loop], centrex, -50, centrez);
			  break;
			 }



        // Signs with the arrows pointing right (clockwise)
		  case SIGNR1:
			 {
			  //printf("\n%d is SIGNR1 %d", loop, level->Obj[loop]);
			  InitTmd(&level->Objects[loop], (u_long *)SIGN1_TMD, 40);
			  RotateModel2(&level->Objects[loop], 3700);
			  SetTmdPos(&level->Objects[loop], x-3000, -50, z+900);
			  break;
			 }

		  case SIGNR2:
			 {
			  //printf("\n%d is SIGNR2 %d", loop, level->Obj[loop]);
			  InitTmd(&level->Objects[loop], (u_long *)SIGN1_TMD, 40);
			  RotateModel2(&level->Objects[loop], 600);
			  SetTmdPos(&level->Objects[loop], x+800, -50, z+3400);
			  break;
			 }
		  case SIGNR3:
			 {
			  //printf("\n%d is SIGNR3 %d", loop, level->Obj[loop]);
			  InitTmd(&level->Objects[loop], (u_long *)SIGN1_TMD, 40);
			  RotateModel2(&level->Objects[loop], 1400);
			  SetTmdPos(&level->Objects[loop], x+1200, -50, z-3000);
			  break;
			 }
		  case SIGNR4:
			 {
			  //printf("\n%d is SIGNR4 %d", loop, level->Obj[loop]);
			  InitTmd(&level->Objects[loop], (u_long *)SIGN1_TMD, 40);
			  RotateModel2(&level->Objects[loop], 2400);
			  SetTmdPos(&level->Objects[loop], x-1200, -50, z-1200);
			  break;
			 }

		  // Signs with the arrows pointing left (anti-clockwise)
		  case SIGNL1:
			 {
			  //printf("\n%d is SIGNL1 %d", loop, level->Obj[loop]);
			  InitTmd(&level->Objects[loop], (u_long *)SIGN2_TMD, 40);
			  RotateModel2(&level->Objects[loop], 3700);
			  SetTmdPos(&level->Objects[loop], x-3000, -50, z+900);
			  break;
			 }

		  case SIGNL2:
			 {
			  //printf("\n%d is SIGNL2 %d", loop, level->Obj[loop]);
			  InitTmd(&level->Objects[loop], (u_long *)SIGN2_TMD, 40);
			  RotateModel2(&level->Objects[loop], 750);
			  SetTmdPos(&level->Objects[loop], x+1200, -50, z+3000);
			  break;
			 }
		  case SIGNL3:
			 {
			  //printf("\n%d is SIGNL3 %d", loop, level->Obj[loop]);
			  InitTmd(&level->Objects[loop], (u_long *)SIGN2_TMD, 40);
			  RotateModel2(&level->Objects[loop], 1400);
			  SetTmdPos(&level->Objects[loop], x+1200, -50, z-3000);
			  break;
			 }
		  case SIGNL4:
			 {
			  //printf("\n%d is SIGNL4 %d", loop, level->Obj[loop]);
			  InitTmd(&level->Objects[loop], (u_long *)SIGN2_TMD, 40);
			  RotateModel2(&level->Objects[loop], 2400);
			  SetTmdPos(&level->Objects[loop], x-3000, -50, z-1200);
			  break;
			 }

		 } // end track obj switch

	 } // end for loop
  printf("\nEnd Init3DWorld();\n");

 }

void DrawWorld(WorldLevel *level)
{
  u_long x, n, Segment;
  //FntPrint("\nDrawWorld()");
  UpdateSegment(level);
  Segment = level->Segment;
  level->Complete[Segment] = TRUE;

  for (x=0; x<SEGMENT_DEPTH; x++)
  {
	n= (x + Segment+LEVEL1_SIZE-1) % LEVEL1_SIZE;  //-1 is the segmet behind
	//printf("\n Drawing=%d",n);
	if (x<4)   // sub-division
	{
	 level->Models[n].Obj.attribute = level->Models[n].Obj.attribute | (1<<9);
	 //printf("\n subdiv on %d",n);
	}
	else level->Models[n].Obj.attribute = level->Models[n].Obj.attribute & (0<<9);
	

	DrawModel(&level->Models[n]);

	// if track obj tehn draw
	if (level->Obj[n]!=NONE) DrawModel(&level->Objects[n]);

  }
	//printf("\nmodel#%d   x=%d  z=%d",(x + Segment % LEVEL1_SIZE),level->Models[x].Coord.coord.t[0],level->Models[x].Coord.coord.t[2]);
  //printf("\nDrawFinished");
}

// Compare the previous,current,next and next+1 segments to see
// if the player has moved forward a segment or back one
// Parameter: WorldLevel pointer
void UpdateSegment(WorldLevel *level)
{
  u_long Segment;
  long prevseg, currentseg, nextseg, nextseg2,ObjPosx, ObjPosz, ObjPosy;

  Segment = level->Segment;
  //FntPrint("\n\nSegment= %d", Segment);

  ObjPosx = level->RefObject->Coord.coord.t[0];
  ObjPosy = level->RefObject->Coord.coord.t[1];
  ObjPosz = level->RefObject->Coord.coord.t[2];

  if (Segment==0) prevseg = LEVEL1_SIZE-1;
  else prevseg= Segment-1;
  nextseg=(Segment+1)%LEVEL1_SIZE;
  nextseg2=(Segment+2)%LEVEL1_SIZE;

  //printf("\np=%d c=%d n=%d n2=%d\nx=%d y=%d z=%d",prevseg,Segment,nextseg, nextseg2,
								  //ObjPosx,ObjPosy,ObjPosz);

  //FntPrint("\nmodel#%d   x=%d  z=%d",Segment, level->Models[Segment].Coord.coord.t[0],
												//level->Models[Segment].Coord.coord.t[2]);

  prevseg =labs(ObjPosx - level->Models[prevseg].Coord.coord.t[0])
			  + labs(ObjPosz - level->Models[prevseg].Coord.coord.t[2]);

  currentseg =labs(ObjPosx- level->Models[Segment].Coord.coord.t[0])
				 +	labs(ObjPosz- level->Models[Segment].Coord.coord.t[2]);

  nextseg =labs(ObjPosx - level->Models[nextseg].Coord.coord.t[0])
			 +	labs(ObjPosz - level->Models[nextseg].Coord.coord.t[2]);

  nextseg2 =labs(ObjPosx - level->Models[nextseg2].Coord.coord.t[0])
			 +	labs(ObjPosz - level->Models[nextseg2].Coord.coord.t[2]);

  //printf("\np=%d c=%d n=%d n2=%d\n", prevseg, currentseg, nextseg, nextseg2);

  // check if the next segment is nearer etc
  // ** Note i have checked them in the most likely order, ie move backwards
  // is the last one.

  if (nextseg<currentseg) level->Segment=((Segment+1)%LEVEL1_SIZE);
  else if (nextseg2<currentseg) level->Segment=((Segment+2)%LEVEL1_SIZE);
  else if ((Segment==0)&&(prevseg<currentseg))  level->Segment=LEVEL1_SIZE-1;
  else if (prevseg<currentseg) level->Segment= Segment-1;
}


